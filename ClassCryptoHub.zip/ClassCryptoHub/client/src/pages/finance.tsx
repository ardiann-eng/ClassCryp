import { useState } from "react";
import PageHero from "@/components/ui/PageHero";
import TransactionForm from "@/components/finance/TransactionForm";
import TransactionTable from "@/components/finance/TransactionTable";
import FinancialDashboard from "@/components/finance/FinancialDashboard";
import IntegratedCashbookView from "@/components/finance/IntegratedCashbookView";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, LineChart, FileText, BarChart3, BookOpen } from "lucide-react";
import { motion } from "framer-motion";

export default function FinancePage() {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div>
      {/* Hero Section */}
      <PageHero
        title="Keuangan Kelas"
        description="Pantau status keuangan dan riwayat transaksi kelas."
        className="from-green-500 to-teal-500"
      />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Finance Dashboard */}
        <div className="mb-12">
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="w-full"
          >
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
              <h2 className="text-2xl font-bold text-dark">Keuangan Kelas</h2>
              <TabsList className="mt-4 sm:mt-0 grid w-full sm:w-auto grid-cols-4 gap-1">
                <TabsTrigger value="dashboard" className="flex items-center gap-2">
                  <LineChart className="h-4 w-4" />
                  <span className="hidden sm:inline">Dashboard</span>
                </TabsTrigger>
                <TabsTrigger value="transactions" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  <span className="hidden sm:inline">Transaksi</span>
                </TabsTrigger>
                <TabsTrigger value="cashbook" className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4" />
                  <span className="hidden sm:inline">Buku Kas</span>
                </TabsTrigger>
                <TabsTrigger value="integrated" className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  <span className="hidden sm:inline">Integrasi</span>
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="dashboard" className="mt-0 space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.3 }}
              >
                <FinancialDashboard />
                <div className="mt-8">
                  <TransactionForm />
                </div>
              </motion.div>
            </TabsContent>
            
            <TabsContent value="transactions" className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.3 }}
              >
                <div className="mb-6">
                  <h3 className="text-xl font-semibold mb-4">Formulir Transaksi</h3>
                  <TransactionForm />
                </div>
                
                <div className="mb-6">
                  <h3 className="text-xl font-semibold mb-4">Riwayat Transaksi</h3>
                  <TransactionTable />
                </div>
              </motion.div>
            </TabsContent>
            
            <TabsContent value="cashbook" className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.3 }}
              >
                <div>
                  <h3 className="text-xl font-semibold mb-4 flex items-center">
                    <Users className="mr-2 text-blue-500" />
                    Buku Kas Kelas
                  </h3>
                  <IntegratedCashbookView />
                </div>
              </motion.div>
            </TabsContent>

            <TabsContent value="integrated" className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                transition={{ duration: 0.3 }}
              >
                <div>
                  <h3 className="text-xl font-semibold mb-4 flex items-center">
                    <BarChart3 className="mr-2 text-blue-500" />
                    Integrasi Keuangan & Buku Kas
                  </h3>
                  <IntegratedCashbookView />
                </div>
              </motion.div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
