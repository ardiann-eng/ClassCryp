import { useQuery } from "@tanstack/react-query";
import PageHero from "@/components/ui/PageHero";
import AnnouncementCard from "@/components/announcements/AnnouncementCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Calendar, ChevronRight } from "lucide-react";
import { format } from "date-fns";
import type { Announcement, Event } from "@shared/schema";

export default function AnnouncementsPage() {
  const { data: announcements, isLoading: announcementsLoading, error: announcementsError } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
  });
  
  const { data: events, isLoading: eventsLoading, error: eventsError } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  return (
    <div>
      {/* Hero Section */}
      <PageHero
        title="Announcements & Schedule"
        description="Stay updated with our latest news and upcoming events."
        className="from-purple-600 to-indigo-600"
      />
      
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Announcements Section */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-dark border-b pb-2">Recent Announcements</h2>
          
          {announcementsLoading ? (
            <div className="space-y-6">
              {Array.from({ length: 3 }).map((_, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
                  <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                    <Skeleton className="h-6 w-64 mb-2 md:mb-0" />
                    <Skeleton className="h-4 w-36" />
                  </div>
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-4" />
                  <div className="flex justify-end">
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
              ))}
            </div>
          ) : announcementsError ? (
            <div className="text-center py-8 text-red-500">
              Failed to load announcements. Please try again later.
            </div>
          ) : announcements && announcements.length > 0 ? (
            <div className="space-y-6">
              {announcements.map(announcement => (
                <AnnouncementCard key={announcement.id} announcement={announcement} />
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No announcements found.
            </div>
          )}
        </div>
        
        {/* Schedule Section */}
        <div>
          <h2 className="text-2xl font-bold mb-6 text-dark border-b pb-2">Upcoming Schedule</h2>
          
          {eventsLoading ? (
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Event</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Array.from({ length: 4 }).map((_, index) => (
                      <TableRow key={index}>
                        <TableCell className="whitespace-nowrap">
                          <Skeleton className="h-4 w-24 mb-1" />
                          <Skeleton className="h-4 w-32" />
                        </TableCell>
                        <TableCell>
                          <Skeleton className="h-5 w-48 mb-1" />
                          <Skeleton className="h-4 w-32" />
                        </TableCell>
                        <TableCell>
                          <Skeleton className="h-4 w-36" />
                        </TableCell>
                        <TableCell className="text-right">
                          <Skeleton className="h-4 w-24 ml-auto" />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          ) : eventsError ? (
            <div className="text-center py-8 text-red-500">
              Failed to load events. Please try again later.
            </div>
          ) : events && events.length > 0 ? (
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-gray-50">
                    <TableRow>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Event</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {events.map(event => (
                      <TableRow key={event.id}>
                        <TableCell className="whitespace-nowrap">
                          <div className="text-sm text-gray-900">{format(new Date(event.date), "MMM d, yyyy")}</div>
                          <div className="text-sm text-gray-500">
                            {format(new Date(event.date), "h:mm a")} - 
                            {event.endTime ? format(new Date(event.endTime), " h:mm a") : ""}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm font-medium text-gray-900">{event.title}</div>
                          <div className="text-sm text-gray-500">Hosted by {event.host}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-gray-900">{event.location}</div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="link" className="text-primary hover:text-blue-700">
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              
              <div className="mt-6 flex justify-center p-4 bg-gray-50 border-t border-gray-200">
                <Button className="bg-primary text-white flex items-center">
                  <Calendar className="mr-2 h-4 w-4" /> Add to Calendar
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No upcoming events found.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
