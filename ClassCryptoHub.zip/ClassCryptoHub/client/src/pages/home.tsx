import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import PageHero from "@/components/ui/PageHero";
import MemberCard from "@/components/members/MemberCard";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle, ChevronLeft, ChevronRight } from "lucide-react";
import type { Member } from "@shared/schema";

export default function HomePage() {
  // Menggunakan API untuk mendapatkan data member yang akan ditampilkan
  // Data member berasal dari data mahasiswa di buku kas
  const { data: members, isLoading, error } = useQuery<Member[]>({
    queryKey: ["/api/members"],
  });
  
  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const membersPerPage = 8; // Menampilkan 8 member per halaman
  
  // Hitung total halaman
  const totalPages = members ? Math.ceil(members.length / membersPerPage) : 0;
  
  // Ambil member untuk halaman saat ini
  const currentMembers = members ? 
    members.slice((currentPage - 1) * membersPerPage, currentPage * membersPerPage) : 
    [];
  
  // Handle page navigation
  const goToPage = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      // Scroll ke atas section member
      const membersSection = document.getElementById('members-section');
      if (membersSection) {
        membersSection.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };
  
  return (
    <div>
      {/* Hero Section */}
      <PageHero
        title="Selamat Datang di CryptGen"
        description="Platform manajemen kelas digital untuk Kelas C Bisnis Digital."
        className="from-blue-500 to-purple-600"
      >
        <Button className="bg-white text-primary hover:bg-gray-100 shadow-lg">
          Bergabung dengan Komunitas
        </Button>
      </PageHero>
      
      {/* About Section */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6 text-dark border-b pb-2">Tentang CryptGen</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <p className="text-gray-700 mb-4">
                CryptGen adalah platform manajemen kelas yang dirancang khusus untuk memfasilitasi komunikasi, kolaborasi, 
                dan administrasi keuangan kelas. Platform ini menyediakan berbagai fitur untuk memudahkan mahasiswa dan dosen 
                dalam mengelola aktivitas kelas sehari-hari.
              </p>
              <p className="text-gray-700 mb-4">
                Dengan sistem Buku Kas terintegrasi, CryptGen memudahkan pengelolaan keuangan kelas seperti pembayaran kas mingguan,
                pencatatan pengeluaran, dan transparansi keuangan untuk semua anggota kelas.
              </p>
            </div>
            <Card className="bg-gray-100 p-6">
              <h3 className="font-semibold text-lg mb-3">Mengapa Menggunakan CryptGen?</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 mt-1 mr-2 h-5 w-5" />
                  <span>Pengelolaan keuangan kelas yang transparan dan akuntabel</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 mt-1 mr-2 h-5 w-5" />
                  <span>Komunikasi kelas yang lebih efektif melalui pengumuman</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 mt-1 mr-2 h-5 w-5" />
                  <span>Manajemen data mahasiswa yang terstruktur dan terorganisir</span>
                </li>
                <li className="flex items-start">
                  <CheckCircle className="text-green-500 mt-1 mr-2 h-5 w-5" />
                  <span>Buku kas digital yang mudah diakses dan diperbarui</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
        
        {/* Members Section */}
        <div id="members-section" className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-dark border-b pb-2">Anggota Kelas</h2>
            {members && members.length > 0 && (
              <div className="text-sm text-gray-500">
                Menampilkan {Math.min(members.length, currentPage * membersPerPage)} dari {members.length} mahasiswa
              </div>
            )}
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, index) => (
                <Card key={index} className="p-4">
                  <div className="flex flex-col items-center">
                    <Skeleton className="w-24 h-24 rounded-full mb-3" />
                    <Skeleton className="h-6 w-32 mb-2" />
                    <Skeleton className="h-4 w-48 mb-2" />
                    <div className="flex space-x-2">
                      <Skeleton className="h-5 w-5" />
                      <Skeleton className="h-5 w-5" />
                      <Skeleton className="h-5 w-5" />
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-500">
              Gagal memuat data anggota kelas. Silakan coba lagi nanti.
            </div>
          ) : members && members.length > 0 ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-6">
                {currentMembers.map((member) => (
                  <MemberCard key={member.id} member={member} />
                ))}
              </div>
              
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-center items-center mt-8 space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  
                  {Array.from({ length: totalPages }).map((_, index) => (
                    <Button
                      key={index + 1}
                      variant={currentPage === index + 1 ? "default" : "outline"}
                      size="sm"
                      onClick={() => goToPage(index + 1)}
                      className={currentPage === index + 1 ? "bg-primary text-white" : ""}
                    >
                      {index + 1}
                    </Button>
                  ))}
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-8 text-gray-500">
              Tidak ada anggota kelas ditemukan.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
