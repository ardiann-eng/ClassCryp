import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Student } from "@shared/schema";
import PageHero from "@/components/ui/PageHero";
import MemberCard from "@/components/members/MemberCard";
import { Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function StudentsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  
  const { data: students, isLoading } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  // Filter students based on search term
  const filteredStudents = students?.filter(student =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    student.nim.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <PageHero
        title="Daftar Mahasiswa"
        description="Manajemen data dan informasi mahasiswa kelas C Bisnis Digital"
        className="mb-8"
      >
        <div className="flex items-center mt-4">
          <Users className="w-5 h-5 mr-2 text-primary" />
          <span className="text-sm text-muted-foreground">{students?.length || 0} mahasiswa terdaftar</span>
        </div>
      </PageHero>

      {/* Search and Filter Controls */}
      <div className="mb-8 flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Input
            type="search"
            placeholder="Cari berdasarkan nama atau NIM..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-4"
          />
        </div>
      </div>

      {/* Students Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="bg-gray-100 rounded-lg p-6 h-64 animate-pulse"></div>
          ))}
        </div>
      ) : filteredStudents?.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-lg text-gray-500">Tidak ada mahasiswa yang ditemukan.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredStudents?.map((student) => (
            <MemberCard
              key={student.id}
              member={{
                id: student.id,
                name: student.name,
                role: `NIM: ${student.nim}`,
                imageUrl: student.imageUrl || undefined,
                twitter: undefined,
                linkedin: undefined,
                email: undefined,
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}