import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Layout from "@/components/layout/Layout";
import HomePage from "@/pages/home";
import AnnouncementsPage from "@/pages/announcements";
import FinancePage from "@/pages/finance";
import ContactPage from "@/pages/contact";
import StudentsPage from "@/pages/students";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={HomePage} />
        <Route path="/announcements" component={AnnouncementsPage} />
        <Route path="/finance" component={FinancePage} />
        <Route path="/contact" component={ContactPage} />
        <Route path="/students" component={StudentsPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
