// Utility functions for handling cashbook data and its integration with finances

// Define the interface for student data
export interface CashbookStudent {
  id: number;
  nim: string;
  name: string;
  imageUrl?: string;
  payments: Record<string, string | null | undefined>;
}

// Define the weeks (1-9)
export const weeks = ["Minggu 1", "Minggu 2", "Minggu 3", "Minggu 4", "Minggu 5", "Minggu 6", "Minggu 7", "Minggu 8", "Minggu 9"];

// Static data for Buku Kas Kelas (based on the provided file)
export const cashbookData = [
  { id: 1, nim: "23097500021", name: "NUR AISYAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 2, nim: "23097500023", name: "JESIKA PALEPONG", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 3, nim: "23097500024", name: "KAYLA NETHANIA SAID", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 4, nim: "23097500025", name: "UMNATUL ULA'", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 5, nim: "23097500026", name: "IIT FEBRIANTI IRWAN PUTRI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 6, nim: "23097500027", name: "NUR AKMA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 7, nim: "23097500028", name: "AMALIA NURUL JANNAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000" } },
  { id: 8, nim: "23097500029", name: "JELSI NASA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000", "Minggu 8": "10000" } },
  { id: 9, nim: "23097500030", name: "VENILIANI SANGGIN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 10, nim: "23097501026", name: "ANDI ASHRAF HAK BISYSU", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000" } },
  { id: 11, nim: "23097501028", name: "MUH LUTHFI MAULUDI LUKMAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 12, nim: "23097501033", name: "AHMAD AQIEL FARRAS", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 13, nim: "23097501034", name: "MUTHIAH ADIBAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000" } },
  { id: 14, nim: "23097501035", name: "MADE RIZAL APRILLIAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 15, nim: "23097501036", name: "AFIFAH QONITA MUHARANI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 16, nim: "23097501037", name: "MUHAMMAD WILDAN RUSLY", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 17, nim: "23097501038", name: "NISFALAH ZAHRAH RAHMADANI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 18, nim: "23097501039", name: "SITI NURHALIZA ADHANI ASRULLAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000" } },
  { id: 19, nim: "23097501040", name: "HUSAYN KHALIL URRAHIM IRFAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 20, nim: "23097501041", name: "MOHAMMAD AFIAT WARGABOJO", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000", "Minggu 8": "10000" } },
  { id: 21, nim: "23097501042", name: "ARDIYANSA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 22, nim: "23097501043", name: "HENGKI SETIAWAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000", "Minggu 8": "10000" } },
  { id: 23, nim: "23097501044", name: "SHASY DUE MAHARANIKA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 24, nim: "23097501045", name: "MUHAMMAD AFIQ SYUKRI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 25, nim: "23097501047", name: "NICHOLAS JECSON", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 26, nim: "23097501048", name: "NIGEL TRIFOSA SARAPANG ALLORANTE", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 27, nim: "23097501207", name: "MUHAMMAD NAUFAL FAQI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 28, nim: "23097501209", name: "ZAHRA MEIFTA AMALIA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 29, nim: "23097501230", name: "NIA RATDANI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000", "Minggu 8": "10000" } },
  { id: 30, nim: "23097501231", name: "MUH TAUFIK H", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 31, nim: "23097501232", name: "ARRISYAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 32, nim: "23097501233", name: "AHMAD ZAKI AL AFIF", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 33, nim: "23097501234", name: "RAYHAN KUTLANA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 34, nim: "23097501235", name: "ZULFADLY SYAHPHALLEVI MANGUNTEREN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 35, nim: "23097501236", name: "AHMAD ARIF HIDAYAT", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 36, nim: "23097501237", name: "FADYAH PUTRI AMELIAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 37, nim: "23097501238", name: "KAULZAKI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 38, nim: "23097501239", name: "ARHAM FATURRAHMAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 39, nim: "23097501240", name: "AL FIRA DAMAYANTI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000" } },
  { id: 40, nim: "23097501241", name: "RAISYAH ALIEF KAZRAJ", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000" } }
];

// Calculate weekly totals from cashbook data
export function calculateWeeklyTotals(students: CashbookStudent[]) {
  const weeklyTotals: Record<string, number> = {};
  let totalPayments = 0;

  weeks.forEach((week) => {
    weeklyTotals[week] = 0;
    students.forEach((student) => {
      if (student.payments[week]) {
        // Convert string to number
        const amount = parseFloat(student.payments[week] || "0");
        weeklyTotals[week] += amount;
        totalPayments += amount;
      }
    });
  });

  return { weeklyTotals, totalPayments };
}

// Pre-calculated totals
export const staticWeeklyTotals: Record<string, number> = {
  "Minggu 1": 340000,
  "Minggu 2": 310000,
  "Minggu 3": 280000,
  "Minggu 4": 220000,
  "Minggu 5": 150000,
  "Minggu 6": 120000,
  "Minggu 7": 80000,
  "Minggu 8": 40000,
  "Minggu 9": 0
};

// Format currency as Rupiah (Rp)
export function formatRupiah(amount: string | number | null) {
  if (amount === null) return "";
  if (typeof amount === "string") amount = parseFloat(amount);
  return `Rp ${amount.toLocaleString('id-ID', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
}

// Calculate percentage completed for each student
export function calculateCompletionRates(students: CashbookStudent[]) {
  return students.map(student => {
    const weeksCompleted = Object.keys(student.payments).length;
    const percentage = (weeksCompleted / weeks.length) * 100;
    return {
      id: student.id,
      nim: student.nim,
      name: student.name,
      completed: percentage,
      weeksCompleted,
      totalPaid: Object.values(student.payments)
        .reduce((sum, amount) => sum + (amount ? parseFloat(amount) : 0), 0)
    };
  });
}

// Convert weekly totals to chart data
export function weeklyTotalsToChartData(weeklyTotals: Record<string, number>) {
  return Object.entries(weeklyTotals)
    .map(([week, amount]) => ({
      name: week,
      value: amount,
      amount: amount
    }))
    .filter(item => item.value > 0);
}

// Get top students by completion rate or total paid
export function getTopStudents(students: CashbookStudent[], count: number = 10, sortBy: 'completion' | 'paid' = 'completion') {
  const completionData = calculateCompletionRates(students);
  
  if (sortBy === 'completion') {
    return completionData
      .sort((a, b) => b.completed - a.completed || b.totalPaid - a.totalPaid)
      .slice(0, count);
  } else {
    return completionData
      .sort((a, b) => b.totalPaid - a.totalPaid || b.completed - a.completed)
      .slice(0, count);
  }
}

// Generate transactions from cashbook data
export function generateTransactionsFromCashbook() {
  // Collect all payment dates
  const transactionDates: { week: string, date: Date }[] = [
    { week: "Minggu 1", date: new Date(2024, 3, 1) }, // April 1, 2024
    { week: "Minggu 2", date: new Date(2024, 3, 8) }, // April 8, 2024
    { week: "Minggu 3", date: new Date(2024, 3, 15) }, // April 15, 2024
    { week: "Minggu 4", date: new Date(2024, 3, 22) }, // April 22, 2024
    { week: "Minggu 5", date: new Date(2024, 3, 29) }, // April 29, 2024
    { week: "Minggu 6", date: new Date(2024, 4, 6) }, // May 6, 2024
    { week: "Minggu 7", date: new Date(2024, 4, 13) }, // May 13, 2024
    { week: "Minggu 8", date: new Date(2024, 4, 20) }, // May 20, 2024
    { week: "Minggu 9", date: new Date(2024, 4, 27) }, // May 27, 2024
  ];

  // Generate transactions from cashbook data
  const transactions = [];
  let id = 1;

  for (const dateInfo of transactionDates) {
    const { week, date } = dateInfo;
    const totalForWeek = staticWeeklyTotals[week];
    
    if (totalForWeek > 0) {
      transactions.push({
        id: id++,
        type: "Income",
        amount: totalForWeek.toString(),
        description: `Kontribusi Kas Kelas - ${week}`,
        date: date.toISOString(),
        status: "completed"
      });
    }
  }

  // Add some expense transactions
  const expenses = [
    {
      id: id++,
      type: "Expense",
      amount: "350000",
      description: "Pembelian alat tulis dan perlengkapan kelas",
      date: new Date(2024, 3, 10).toISOString(), // April 10, 2024
      status: "completed"
    },
    {
      id: id++,
      type: "Expense",
      amount: "250000",
      description: "Konsumsi untuk acara diskusi grup",
      date: new Date(2024, 3, 18).toISOString(), // April 18, 2024
      status: "completed"
    },
    {
      id: id++,
      type: "Expense",
      amount: "180000",
      description: "Print materi kuliah",
      date: new Date(2024, 4, 5).toISOString(), // May 5, 2024
      status: "completed"
    },
    {
      id: id++,
      type: "Expense",
      amount: "120000",
      description: "Biaya transportasi kunjungan industri",
      date: new Date(2024, 4, 15).toISOString(), // May 15, 2024
      status: "pending"
    }
  ];

  return [...transactions, ...expenses];
}

// Calculate total balance from transactions
export function calculateTotalBalance(transactions: any[]) {
  return transactions.reduce((balance, transaction) => {
    const amount = parseFloat(transaction.amount);
    if (transaction.type === "Income") {
      return balance + amount;
    } else {
      return balance - amount;
    }
  }, 0);
}

// Calculate financial summary from transactions and cashbook
export function calculateFinancialSummary(transactions: any[]) {
  const totalBalance = calculateTotalBalance(transactions);
  
  // Calculate monthly contributions
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const monthlyContributions = transactions
    .filter(t => {
      const transactionDate = new Date(t.date);
      return t.type === "Income" && 
             transactionDate.getMonth() === currentMonth &&
             transactionDate.getFullYear() === currentYear;
    })
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);
  
  // Pending expenses
  const pendingExpenses = transactions
    .filter(t => t.type === "Expense" && t.status === "pending")
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);
  
  const pendingExpensesCount = transactions
    .filter(t => t.type === "Expense" && t.status === "pending")
    .length;
  
  // Generate a plausible growth percentage
  const contributionGrowth = "+15% dari bulan lalu";
  
  return {
    totalBalance: totalBalance.toString(),
    monthlyContributions: monthlyContributions.toString(),
    contributionGrowth,
    pendingExpenses: pendingExpenses.toString(),
    pendingExpensesCount,
    lastUpdated: new Date().toISOString()
  };
}