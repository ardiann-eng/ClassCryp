import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

export async function apiRequest(
  endpoint: string,
  options?: RequestInit,
): Promise<Response> {
  // Jika options disediakan gunakan itu, jika tidak buat default
  const fetchOptions: RequestInit = {
    credentials: "include",
    ...options
  };
  
  // Jika body adalah FormData, jangan tambahkan Content-Type (browser akan otomatis menambahkan dengan boundary)
  if (options?.body && !(options.body instanceof FormData)) {
    fetchOptions.headers = {
      "Content-Type": "application/json",
      ...options.headers,
    };
    
    // Jika body tidak berupa string atau FormData, stringify ke JSON
    if (typeof options.body !== 'string' && !(options.body instanceof FormData)) {
      fetchOptions.body = JSON.stringify(options.body);
    }
  }

  const res = await fetch(endpoint, fetchOptions);
  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
