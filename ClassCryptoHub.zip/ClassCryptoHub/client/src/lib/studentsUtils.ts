// Utility untuk mengubah data students dari buku kas menjadi data member

import { cashbookData } from './cashbookUtils';
import type { Member, InsertMember } from '@shared/schema';

// Generate random hex color
const getRandomColor = (): string => {
  const colors = [
    '#4361EE', '#3F37C9', '#4895EF', '#4CC9F0', // biru
    '#F72585', '#B5179E', '#7209B7', '#560BAD', // merah/ungu
    '#F94144', '#F3722C', '#F8961E', '#F9C74F', // merah/oranye
    '#90BE6D', '#43AA8B', '#4D908E', '#577590', // hijau/biru-hijau
  ];
  return colors[Math.floor(Math.random() * colors.length)];
};

// Generate avatar URL from student name
const generateAvatarUrl = (name: string, nim: string): string => {
  // URL untuk generate avatar dengan inisial
  const initials = name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);

  const bgColor = getRandomColor();
  
  // Buat identifier unik dari nim
  return `https://ui-avatars.com/api/?name=${initials}&background=${bgColor.substring(1)}&color=fff&size=256&bold=true&font-size=0.4`;
};

// Konversi data students dari buku kas menjadi data member
export const generateMembersFromCashbook = (): InsertMember[] => {
  return cashbookData.map(student => {
    // Ambil hanya nama depan untuk username
    const firstName = student.name.split(' ')[0].toLowerCase();
    
    return {
      name: student.name,
      role: `Mahasiswa - ${student.nim}`,
      imageUrl: generateAvatarUrl(student.name, student.nim),
      // username juga menggunakan nim untuk keunikan
      twitter: `${firstName}${student.nim.substring(6, 10)}`,
      linkedin: `${firstName}-${student.nim.substring(6, 10)}`,
      email: `${firstName.toLowerCase()}.${student.nim}@student.example.com`
    };
  });
};

// Data member yang sudah dibuat
export const cashbookMembers = generateMembersFromCashbook();