import { ReactNode } from "react";
import { cn } from "@/lib/utils";

interface PageHeroProps {
  title: string;
  description: string;
  className?: string;
  children?: ReactNode;
}

export default function PageHero({ 
  title, 
  description, 
  className, 
  children 
}: PageHeroProps) {
  return (
    <div className={cn("bg-gradient-to-r p-8 lg:p-16 text-white", className)}>
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl lg:text-4xl font-bold mb-4">{title}</h1>
        <p className="text-lg lg:text-xl mb-6 max-w-2xl">{description}</p>
        {children}
      </div>
    </div>
  );
}
