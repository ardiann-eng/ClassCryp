import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { 
  PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid
} from 'recharts';

// Define the interface for student data from the API
interface Student {
  id: number;
  nim: string;
  name: string;
  imageUrl?: string;
  payments: {
    [key: string]: string | null;
  };
}

// Define the weeks (1-9)
const weeks = ["Minggu 1", "Minggu 2", "Minggu 3", "Minggu 4", "Minggu 5", "Minggu 6", "Minggu 7", "Minggu 8", "Minggu 9"];

// Static data for Buku Kas Kelas (based on the provided file)
const staticData = [
  { id: 1, nim: "23097500021", name: "NUR AISYAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 2, nim: "23097500023", name: "JESIKA PALEPONG", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 3, nim: "23097500024", name: "KAYLA NETHANIA SAID", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 4, nim: "23097500025", name: "UMNATUL ULA'", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 5, nim: "23097500026", name: "IIT FEBRIANTI IRWAN PUTRI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 6, nim: "23097500027", name: "NUR AKMA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 7, nim: "23097500028", name: "AMALIA NURUL JANNAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000" } },
  { id: 8, nim: "23097500029", name: "JELSI NASA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000", "Minggu 8": "10000" } },
  { id: 9, nim: "23097500030", name: "VENILIANI SANGGIN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 10, nim: "23097501026", name: "ANDI ASHRAF HAK BISYSU", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000" } },
  { id: 11, nim: "23097501028", name: "MUH LUTHFI MAULUDI LUKMAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 12, nim: "23097501033", name: "AHMAD AQIEL FARRAS", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 13, nim: "23097501034", name: "MUTHIAH ADIBAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000" } },
  { id: 14, nim: "23097501035", name: "MADE RIZAL APRILLIAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 15, nim: "23097501036", name: "AFIFAH QONITA MUHARANI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 16, nim: "23097501037", name: "MUHAMMAD WILDAN RUSLY", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 17, nim: "23097501038", name: "NISFALAH ZAHRAH RAHMADANI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 18, nim: "23097501039", name: "SITI NURHALIZA ADHANI ASRULLAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000" } },
  { id: 19, nim: "23097501040", name: "HUSAYN KHALIL URRAHIM IRFAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 20, nim: "23097501041", name: "MOHAMMAD AFIAT WARGABOJO", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000", "Minggu 8": "10000" } },
  { id: 21, nim: "23097501042", name: "ARDIYANSA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 22, nim: "23097501043", name: "HENGKI SETIAWAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000", "Minggu 8": "10000" } },
  { id: 23, nim: "23097501044", name: "SHASY DUE MAHARANIKA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 24, nim: "23097501045", name: "MUHAMMAD AFIQ SYUKRI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 25, nim: "23097501047", name: "NICHOLAS JECSON", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 26, nim: "23097501048", name: "NIGEL TRIFOSA SARAPANG ALLORANTE", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 27, nim: "23097501207", name: "MUHAMMAD NAUFAL FAQI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 28, nim: "23097501209", name: "ZAHRA MEIFTA AMALIA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 29, nim: "23097501230", name: "NIA RATDANI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000", "Minggu 6": "10000", "Minggu 7": "10000", "Minggu 8": "10000" } },
  { id: 30, nim: "23097501231", name: "MUH TAUFIK H", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 31, nim: "23097501232", name: "ARRISYAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 32, nim: "23097501233", name: "AHMAD ZAKI AL AFIF", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 33, nim: "23097501234", name: "RAYHAN KUTLANA", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000" } },
  { id: 34, nim: "23097501235", name: "ZULFADLY SYAHPHALLEVI MANGUNTEREN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 35, nim: "23097501236", name: "AHMAD ARIF HIDAYAT", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 36, nim: "23097501237", name: "FADYAH PUTRI AMELIAH", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 37, nim: "23097501238", name: "KAULZAKI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 38, nim: "23097501239", name: "ARHAM FATURRAHMAN", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000", "Minggu 4": "10000", "Minggu 5": "10000" } },
  { id: 39, nim: "23097501240", name: "AL FIRA DAMAYANTI", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000" } },
  { id: 40, nim: "23097501241", name: "RAISYAH ALIEF KAZRAJ", payments: { "Minggu 1": "10000", "Minggu 2": "10000", "Minggu 3": "10000" } }
];

// Define weekly totals
const staticWeeklyTotals = {
  "Minggu 1": 340000,
  "Minggu 2": 310000,
  "Minggu 3": 280000,
  "Minggu 4": 220000,
  "Minggu 5": 150000,
  "Minggu 6": 120000,
  "Minggu 7": 80000,
  "Minggu 8": 40000,
  "Minggu 9": 0
};

// Define total amount
const staticTotalAmount = 1700000;

// Colors for charts
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#fa8231', '#a55eea', '#45aaf2'];

export default function ClassCashbook() {
  const [showAnalytics, setShowAnalytics] = useState(false);
  
  // Use static data instead of API fetch
  const students = staticData;
  const weeklyTotals = staticWeeklyTotals;
  const totalPayments = staticTotalAmount;
  const isLoading = false;
  const error = null;

  // Format currency as Rupiah (Rp)
  const formatRupiah = (amount: string | number | null) => {
    if (amount === null) return "";
    if (typeof amount === "string") amount = parseFloat(amount);
    return `Rp ${amount.toLocaleString('id-ID', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
  };

  // Prepare chart data
  const pieChartData = Object.entries(weeklyTotals).map(([week, amount]) => ({
    name: week,
    value: amount
  })).filter(item => item.value > 0);

  const barChartData = Object.entries(weeklyTotals).map(([week, amount]) => ({
    name: week,
    amount: amount
  })).filter(item => item.amount > 0);

  // Calculate percentage completed for each student
  const completionData = students.map(student => {
    const weeksCompleted = Object.keys(student.payments).length;
    const percentage = (weeksCompleted / weeks.length) * 100;
    return {
      name: student.name,
      completed: percentage
    };
  }).sort((a, b) => b.completed - a.completed).slice(0, 10);

  return (
    <Card className="border border-gray-200 mt-8">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row justify-between items-center mb-6">
          <h3 className="text-xl font-bold mb-2 md:mb-0 text-center md:text-left">BUKU KAS KELAS C BISNIS DIGITAL</h3>
          <button
            onClick={() => setShowAnalytics(!showAnalytics)}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
          >
            {showAnalytics ? 'Lihat Tabel' : 'Lihat Analisis'}
          </button>
        </div>
        
        {isLoading ? (
          <div className="py-8 flex justify-center">
            <Skeleton className="h-64 w-full" />
          </div>
        ) : error ? (
          <div className="py-8 text-center text-red-500">
            Gagal memuat data pembayaran mahasiswa. Silakan coba lagi nanti.
          </div>
        ) : showAnalytics ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="space-y-8"
          >
            {/* Overview cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <CardContent className="p-4">
                  <h4 className="text-lg font-medium text-blue-700">Total Pembayaran</h4>
                  <p className="text-2xl font-bold text-blue-800 mt-2">{formatRupiah(totalPayments)}</p>
                  <p className="text-sm text-blue-600 mt-1">
                    Total dari seluruh minggu
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                <CardContent className="p-4">
                  <h4 className="text-lg font-medium text-green-700">Jumlah Mahasiswa</h4>
                  <p className="text-2xl font-bold text-green-800 mt-2">{students.length}</p>
                  <p className="text-sm text-green-600 mt-1">
                    Total mahasiswa
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
                <CardContent className="p-4">
                  <h4 className="text-lg font-medium text-amber-700">Rata-rata Pembayaran</h4>
                  <p className="text-2xl font-bold text-amber-800 mt-2">
                    {formatRupiah(totalPayments / students.length)}
                  </p>
                  <p className="text-sm text-amber-600 mt-1">
                    Per mahasiswa
                  </p>
                </CardContent>
              </Card>
            </div>
            
            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardContent className="p-4">
                  <h4 className="text-lg font-semibold mb-4">Distribusi Pembayaran per Minggu</h4>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieChartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {pieChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatRupiah(value as number)} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <h4 className="text-lg font-semibold mb-4">Total Pembayaran per Minggu</h4>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={barChartData}
                        margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => formatRupiah(value as number)} />
                        <Legend />
                        <Bar 
                          dataKey="amount" 
                          name="Jumlah" 
                          fill="#82ca9d"
                        >
                          {barChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Top 10 students by completion rate */}
            <Card>
              <CardContent className="p-4">
                <h4 className="text-lg font-semibold mb-4">Top 10 Mahasiswa (Tingkat Pelunasan)</h4>
                <div className="space-y-3">
                  {completionData.map((student, index) => (
                    <div key={index} className="flex flex-col">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">{student.name}</span>
                        <span className="text-sm font-medium">{student.completed.toFixed(0)}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2.5">
                        <div 
                          className="bg-blue-600 h-2.5 rounded-full" 
                          style={{ width: `${student.completed}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="overflow-x-auto"
          >
            <table className="min-w-full border-collapse border border-gray-300 text-sm">
              <thead>
                <tr className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                  <th className="border border-gray-300 py-2 px-3 text-center">NO</th>
                  <th className="border border-gray-300 py-2 px-3 text-center">NIM</th>
                  <th className="border border-gray-300 py-2 px-3 text-center">NAMA</th>
                  {weeks.map((week) => (
                    <th 
                      key={week} 
                      className="border border-gray-300 py-2 px-3 text-center"
                    >
                      {week}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {students.map((student, index) => (
                  <tr key={student.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="border border-gray-300 py-2 px-3 text-center">{index + 1}</td>
                    <td className="border border-gray-300 py-2 px-3">{student.nim}</td>
                    <td className="border border-gray-300 py-2 px-3">{student.name}</td>
                    {weeks.map((week) => (
                      <td 
                        key={`${student.id}-${week}`} 
                        className="border border-gray-300 py-2 px-3 text-right"
                      >
                        {student.payments && Object.prototype.hasOwnProperty.call(student.payments, week) && student.payments[week as keyof typeof student.payments] ? 'Rp 10.000,00' : ""}
                      </td>
                    ))}
                  </tr>
                ))}
                <tr className="bg-blue-100 font-semibold text-blue-800">
                  <td colSpan={3} className="border border-gray-300 py-2 px-3 text-right">TOTAL PERMINGGU</td>
                  {weeks.map((week) => (
                    <td key={`total-${week}`} className="border border-gray-300 py-2 px-3 text-right">
                      {weeklyTotals && Object.prototype.hasOwnProperty.call(weeklyTotals, week) && weeklyTotals[week as keyof typeof weeklyTotals] > 0 ? formatRupiah(weeklyTotals[week as keyof typeof weeklyTotals]) : ""}
                    </td>
                  ))}
                </tr>
                <tr className="bg-blue-200 font-bold text-blue-900">
                  <td colSpan={3} className="border border-gray-300 py-2 px-3 text-right">TOTAL KESELURUHAN</td>
                  <td colSpan={weeks.length} className="border border-gray-300 py-2 px-3 pl-4">
                    {formatRupiah(totalPayments)} <span className="ml-2 text-sm">(30,86% dari target Rp 2.224.620,00)</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}