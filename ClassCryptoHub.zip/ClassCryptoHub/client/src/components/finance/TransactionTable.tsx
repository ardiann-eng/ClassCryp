import { useState } from "react";
import { format } from "date-fns";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  formatRupiah, 
  generateTransactionsFromCashbook 
} from '@/lib/cashbookUtils';
import type { Transaction } from "@shared/schema";

export default function TransactionTable() {
  const [activeTab, setActiveTab] = useState("all");
  
  // Fetch transactions from API
  const { data: apiTransactions = [], isLoading, error } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });
  
  // Get transactions from cashbook data
  const cashbookTransactions = generateTransactionsFromCashbook();
  
  // Per permintaan, hanya gunakan data dari buku kas dan pengeluaran esensial
  const expenses = apiTransactions.filter(t => t.type === "Expense");
  const allTransactions = [...cashbookTransactions, ...expenses];
  
  if (isLoading) {
    return <TransactionTableSkeleton />;
  }
  
  if (error) {
    return (
      <div className="text-center py-8 text-red-500">
        Gagal memuat data transaksi. Silakan coba lagi nanti.
      </div>
    );
  }
  
  if (!allTransactions || allTransactions.length === 0) {
    return (
      <div className="text-center py-8 text-gray-500">
        Tidak ada transaksi. Tambahkan satu untuk memulai.
      </div>
    );
  }

  // Display specific transactions based on active tab
  const displayTransactions = activeTab === "all" ? allTransactions :
                            activeTab === "cashbook" ? cashbookTransactions :
                            expenses;
  
  // Helper function to format amount with sign and color
  const formatAmountWithColor = (amount: string, type: string) => {
    const isNegative = type === "Expense" || type === "Investment" || type === "Withdrawal";
    
    return {
      sign: isNegative ? "-" : "+",
      color: isNegative ? "text-red-600" : "text-green-600",
      value: formatRupiah(amount)
    };
  };
  
  // Calculate total balance
  const totalBalance = displayTransactions.reduce((sum, transaction) => {
    const amount = parseFloat(transaction.amount.toString());
    const isNegative = transaction.type === "Expense" || transaction.type === "Investment" || transaction.type === "Withdrawal";
    return sum + (isNegative ? -amount : amount);
  }, 0);
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200"
    >
      <div className="p-4 border-b border-gray-200">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="all">Semua Transaksi</TabsTrigger>
            <TabsTrigger value="cashbook">Pembayaran Kas Kelas</TabsTrigger>
            <TabsTrigger value="other">Pengeluaran</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
    
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gradient-to-r from-primary to-primary/80">
            <TableRow>
              <TableHead className="text-white font-bold">No</TableHead>
              <TableHead className="text-white font-bold">Tanggal</TableHead>
              <TableHead className="text-white font-bold">Deskripsi</TableHead>
              <TableHead className="text-white font-bold">Jenis</TableHead>
              <TableHead className="text-white font-bold text-right">Jumlah</TableHead>
              <TableHead className="text-white font-bold text-right">Saldo</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {displayTransactions
              .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
              .map((transaction, index) => {
                const { sign, color, value } = formatAmountWithColor(transaction.amount.toString(), transaction.type);
                
                // Calculate running balance
                const runningBalance = displayTransactions
                  .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                  .slice(0, displayTransactions
                    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                    .findIndex(t => t === transaction) + 1)
                  .reduce((sum, t) => {
                    const amt = parseFloat(t.amount.toString());
                    const isNeg = t.type === "Expense" || t.type === "Investment" || t.type === "Withdrawal";
                    return sum + (isNeg ? -amt : amt);
                  }, 0);
                
                // Determine row background color (alternating)
                const rowBgClass = index % 2 === 0 ? "bg-white" : "bg-gray-50";
                
                // Check if transaction is from cashbook
                const isFromCashbook = transaction.description.includes("Kontribusi Kas Kelas");
                
                return (
                  <motion.tr
                    key={transaction.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    className={`${rowBgClass} ${isFromCashbook ? "bg-blue-50" : ""}`}
                  >
                    <TableCell className="font-medium">{index + 1}</TableCell>
                    <TableCell className="whitespace-nowrap">
                      {format(new Date(transaction.date), "dd/MM/yyyy")}
                    </TableCell>
                    <TableCell className="font-medium">{transaction.description}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={
                        transaction.type === "Income" ? "bg-green-100 text-green-800 border-green-200" : 
                        transaction.type === "Expense" ? "bg-red-100 text-red-800 border-red-200" : 
                        transaction.type === "Investment" ? "bg-purple-100 text-purple-800 border-purple-200" : 
                        "bg-orange-100 text-orange-800 border-orange-200"
                      }>
                        {transaction.type === "Income" ? "Pemasukan" : 
                         transaction.type === "Expense" ? "Pengeluaran" : 
                         transaction.type === "Investment" ? "Investasi" : "Penarikan"}
                      </Badge>
                    </TableCell>
                    <TableCell className={`whitespace-nowrap font-bold text-right ${color}`}>
                      <motion.span
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.5, delay: index * 0.05 + 0.2 }}
                      >
                        {sign}{value}
                      </motion.span>
                    </TableCell>
                    <TableCell className="whitespace-nowrap font-bold text-right">
                      {formatRupiah(runningBalance)}
                    </TableCell>
                  </motion.tr>
                );
              })}
            
            {/* Total row */}
            <motion.tr 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-gray-200 font-bold"
            >
              <TableCell colSpan={4} className="text-right">Total Saldo</TableCell>
              <TableCell colSpan={2} className={`text-right ${totalBalance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {formatRupiah(totalBalance)}
              </TableCell>
            </motion.tr>
          </TableBody>
        </Table>
      </div>
    </motion.div>
  );
}

function TransactionTableSkeleton() {
  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200">
      <div className="p-4 border-b border-gray-200">
        <Skeleton className="h-10 w-full" />
      </div>
      
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gradient-to-r from-primary to-primary/80">
            <TableRow>
              <TableHead className="text-white font-bold">No</TableHead>
              <TableHead className="text-white font-bold">Tanggal</TableHead>
              <TableHead className="text-white font-bold">Deskripsi</TableHead>
              <TableHead className="text-white font-bold">Jenis</TableHead>
              <TableHead className="text-white font-bold text-right">Jumlah</TableHead>
              <TableHead className="text-white font-bold text-right">Saldo</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {Array.from({ length: 5 }).map((_, index) => (
              <TableRow key={index} className={index % 2 === 0 ? "bg-white" : "bg-gray-50"}>
                <TableCell><Skeleton className="h-4 w-6" /></TableCell>
                <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                <TableCell><Skeleton className="h-6 w-20" /></TableCell>
                <TableCell className="text-right"><Skeleton className="h-4 w-20 ml-auto" /></TableCell>
                <TableCell className="text-right"><Skeleton className="h-4 w-20 ml-auto" /></TableCell>
              </TableRow>
            ))}
            <TableRow className="bg-gray-200 font-bold">
              <TableCell colSpan={4} className="text-right"><Skeleton className="h-5 w-32 ml-auto" /></TableCell>
              <TableCell colSpan={2} className="text-right"><Skeleton className="h-5 w-24 ml-auto" /></TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
