import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { format } from 'date-fns';
import {
  cashbookData,
  weeks,
  staticWeeklyTotals,
  formatRupiah,
  weeklyTotalsToChartData,
  getTopStudents,
  calculateCompletionRates,
  generateTransactionsFromCashbook,
  calculateTotalBalance,
  calculateFinancialSummary
} from '@/lib/cashbookUtils';
import type { Transaction, FinancialSummary } from "@shared/schema";

// Colors for the charts
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export default function FinancialDashboard() {
  const [activeChart, setActiveChart] = useState('overview');

  // Fetch transactions data from API
  const { data: apiTransactions = [], isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions'],
  });

  // Fetch financial summary from API
  const { data: apiSummary, isLoading: isLoadingSummary } = useQuery<FinancialSummary>({
    queryKey: ['/api/financial-summary'],
  });

  // Get transactions from cashbook data (student payments)
  const cashbookTransactions = generateTransactionsFromCashbook();
  
  // Combine transactions from API and cashbook, removing duplicates
  const uniqueDescriptions = new Set(cashbookTransactions.map(t => t.description));
  const filteredApiTransactions = apiTransactions.filter(t => !uniqueDescriptions.has(t.description));
  
  const allTransactions = [...cashbookTransactions, ...filteredApiTransactions];
  
  // Calculate financial summary using combined transactions
  const generatedSummary = calculateFinancialSummary(allTransactions);
  
  // Use API summary if available, otherwise use generated summary
  const summary = apiSummary || generatedSummary;

  // Format date
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), 'dd/MM/yyyy');
  };

  // Generate data for weekly payment chart directly from cashbook data
  const weeklyPaymentBarData = Object.entries(staticWeeklyTotals)
    .filter(([_, amount]) => amount > 0)
    .map(([week, amount]) => ({
      name: week,
      amount: amount
    }));

  // Process transactions data for charts (including cashbook data)
  const processTransactionsData = () => {
    // Group by type (Income, Expense, Investment)
    const byType = allTransactions.reduce((acc: Record<string, number>, transaction) => {
      const { type, amount } = transaction;
      if (!acc[type]) acc[type] = 0;
      acc[type] += parseFloat(amount.toString());
      return acc;
    }, {});

    const pieData = Object.keys(byType).map(key => ({
      name: key === 'Income' ? 'Pemasukan' : key === 'Expense' ? 'Pengeluaran' : 'Investasi',
      value: byType[key]
    }));

    // Process monthly data for line chart
    const byMonth: Record<string, Record<string, number>> = {};
    
    allTransactions.forEach(transaction => {
      const date = new Date(transaction.date);
      const month = `${date.getMonth() + 1}/${date.getFullYear()}`;
      
      if (!byMonth[month]) {
        byMonth[month] = { Pemasukan: 0, Pengeluaran: 0, Investasi: 0 };
      }
      
      const typeKey = transaction.type === 'Income' ? 'Pemasukan' : 
                     transaction.type === 'Expense' ? 'Pengeluaran' : 'Investasi';
      
      byMonth[month][typeKey] += parseFloat(transaction.amount.toString());
    });

    const lineData = Object.keys(byMonth).sort().map(month => ({
      month,
      ...byMonth[month]
    }));

    // Process status data for bar chart
    const byStatus = allTransactions.reduce((acc: Record<string, number>, transaction) => {
      const { status, amount } = transaction;
      if (!acc[status]) acc[status] = 0;
      acc[status] += parseFloat(amount.toString());
      return acc;
    }, {});

    const barData = Object.keys(byStatus).map(key => ({
      name: key === 'completed' ? 'Selesai' : 'Tertunda',
      amount: byStatus[key]
    }));

    // Generate student payment completion data
    const studentCompletionData = getTopStudents(cashbookData, 5).map(student => ({
      name: student.name,
      amount: student.totalPaid,
      completion: student.completed
    }));

    return { pieData, lineData, barData, studentCompletionData };
  };

  const { pieData, lineData, barData, studentCompletionData } = processTransactionsData();

  if (isLoadingSummary || isLoadingTransactions) {
    return (
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <Skeleton className="h-8 w-1/2" />
            <Skeleton className="h-4 w-3/4" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[300px] w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Financial summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl text-blue-700">Total Saldo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-800">
                {summary ? formatRupiah(summary.totalBalance) : 'Rp 0,00'}
              </div>
              <p className="text-sm text-blue-600 mt-1">
                Termasuk kas kelas Rp 1.700.000,00
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl text-green-700">Kontribusi Kas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-800">
                Rp 1.700.000,00
              </div>
              <p className="text-sm text-green-600 mt-1">
                Dari 40 mahasiswa
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl text-amber-700">Pengeluaran</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-800">
                Rp 900.000,00
              </div>
              <p className="text-sm text-amber-600 mt-1">
                4 transaksi pengeluaran
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl text-purple-700">Sisa Saldo</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-800">
                Rp 800.000,00
              </div>
              <p className="text-sm text-purple-600 mt-1">
                Saldo kas setelah pengeluaran
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Charts */}
      <Card>
        <CardHeader>
          <CardTitle>Visualisasi Keuangan</CardTitle>
          <CardDescription>Lihat data keuangan dalam berbagai visualisasi</CardDescription>
          <Tabs defaultValue={activeChart} onValueChange={setActiveChart} className="w-full">
            <TabsList className="grid grid-cols-4 w-full sm:w-[400px]">
              <TabsTrigger value="overview">Ikhtisar</TabsTrigger>
              <TabsTrigger value="weekly">Mingguan</TabsTrigger>
              <TabsTrigger value="distribution">Distribusi</TabsTrigger>
              <TabsTrigger value="student">Mahasiswa</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <TabsContent value="overview" className="mt-0 h-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={lineData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatRupiah(value as number)} />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="Pemasukan"
                    stroke="#00C49F"
                    activeDot={{ r: 8 }}
                    strokeWidth={2}
                  />
                  <Line
                    type="monotone"
                    dataKey="Pengeluaran"
                    stroke="#FF8042"
                    strokeWidth={2}
                  />
                </LineChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="weekly" className="mt-0 h-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={weeklyPaymentBarData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip formatter={(value) => formatRupiah(value as number)} />
                  <Legend />
                  <Bar 
                    dataKey="amount" 
                    name="Pembayaran Kas" 
                    fill="#00C49F"
                    animationBegin={200}
                    animationDuration={1500}
                  >
                    {weeklyPaymentBarData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="distribution" className="mt-0 h-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={150}
                    fill="#8884d8"
                    dataKey="value"
                    nameKey="name"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    animationBegin={200}
                    animationDuration={1500}
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatRupiah(value as number)} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </TabsContent>

            <TabsContent value="student" className="mt-0 h-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={studentCompletionData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value, name) => {
                      if (name === 'amount') return formatRupiah(value as number);
                      if (name === 'completion') return `${value}%`;
                      return value;
                    }}
                  />
                  <Legend />
                  <Bar 
                    dataKey="amount" 
                    name="Total Dibayarkan" 
                    fill="#8884d8"
                    animationBegin={200}
                    animationDuration={1500}
                  >
                    {studentCompletionData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </TabsContent>
          </div>
        </CardContent>
      </Card>

      {/* Recent Transactions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Transaksi Kas Kelas</CardTitle>
            <CardDescription>Transaksi dari pembayaran kas mahasiswa</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full border-collapse">
                <thead>
                  <tr className="border-b bg-gray-100">
                    <th className="py-2 px-3 text-left font-semibold">Tanggal</th>
                    <th className="py-2 px-3 text-left font-semibold">Deskripsi</th>
                    <th className="py-2 px-3 text-left font-semibold">Tipe</th>
                    <th className="py-2 px-3 text-left font-semibold">Status</th>
                    <th className="py-2 px-3 text-right font-semibold">Jumlah</th>
                  </tr>
                </thead>
                <tbody>
                  {cashbookTransactions.slice(0, 8).map((transaction, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50 transition-colors">
                      <td className="py-2 px-3">{formatDate(transaction.date)}</td>
                      <td className="py-2 px-3">{transaction.description}</td>
                      <td className="py-2 px-3">
                        <span className="inline-block px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                          Pemasukan
                        </span>
                      </td>
                      <td className="py-2 px-3">
                        <span className="inline-block px-2 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-800">
                          Selesai
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right font-medium text-green-600">
                        {formatRupiah(transaction.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}