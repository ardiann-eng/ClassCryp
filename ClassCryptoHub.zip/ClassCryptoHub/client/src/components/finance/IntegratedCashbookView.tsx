import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "framer-motion";
import { 
  PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line,
  Area, AreaChart, ComposedChart
} from 'recharts';
import {
  cashbookData,
  weeks,
  staticWeeklyTotals,
  formatRupiah,
  weeklyTotalsToChartData,
  getTopStudents,
  calculateCompletionRates,
  generateTransactionsFromCashbook,
  calculateTotalBalance,
  calculateFinancialSummary
} from '@/lib/cashbookUtils';
import type { Transaction, FinancialSummary } from "@shared/schema";

// Colors for charts
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#fa8231', '#a55eea', '#45aaf2'];

export default function IntegratedCashbookView() {
  const [activeTab, setActiveTab] = useState('cashbook');
  const [showAnalytics, setShowAnalytics] = useState(false);
  
  // Fetch transactions data
  const { data: apiTransactions = [], isLoading: isLoadingTransactions } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions'],
  });

  // Fetch financial summary
  const { data: apiSummary, isLoading: isLoadingSummary } = useQuery<FinancialSummary>({
    queryKey: ['/api/financial-summary'],
  });

  // Use static data
  const students = cashbookData;
  const weeklyTotals = staticWeeklyTotals;
  const totalPayments = 1700000; // From static data

  // Merge cashbook transactions with API transactions
  const cashbookTransactions = generateTransactionsFromCashbook();
  
  // Filter out duplicates and combine transactions
  const uniqueDescriptions = new Set(cashbookTransactions.map(t => t.description));
  const filteredApiTransactions = apiTransactions.filter(t => !uniqueDescriptions.has(t.description));
  
  const allTransactions = [...cashbookTransactions, ...filteredApiTransactions];
  
  // Calculate the financial summary
  const generatedSummary = calculateFinancialSummary(allTransactions);
  
  // Use API summary if available, otherwise use generated summary
  const summary = apiSummary || generatedSummary;
  
  // Prepare chart data
  const pieChartData = weeklyTotalsToChartData(weeklyTotals);
  const barChartData = pieChartData;

  // Calculate completion rates
  const topStudents = getTopStudents(students, 10);
  const studentCompletionRates = calculateCompletionRates(students);
  
  // Prepare transaction data for timeline chart
  const cashbookTimeline = cashbookTransactions
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map(t => ({
      date: new Date(t.date).toLocaleDateString('id-ID'),
      amount: parseFloat(t.amount),
      type: t.type,
      income: t.type === 'Income' ? parseFloat(t.amount) : 0,
      expense: t.type === 'Expense' ? parseFloat(t.amount) : 0
    }));

  // Calculate running balance for cashbook transactions
  let runningBalance = 0;
  const cashbookBalanceTimeline = cashbookTransactions
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .map(t => {
      if (t.type === 'Income') {
        runningBalance += parseFloat(t.amount);
      } else {
        runningBalance -= parseFloat(t.amount);
      }
      return {
        date: new Date(t.date).toLocaleDateString('id-ID'),
        balance: runningBalance
      };
    });

  // Calculate payment progress percentage
  const totalWeeks = weeks.length;
  const totalPaymentsNeeded = students.length * totalWeeks * 10000;
  const progressPercentage = (totalPayments / totalPaymentsNeeded) * 100;

  // Calculate average payment per student
  const averagePaymentPerStudent = totalPayments / students.length;

  const isLoading = isLoadingTransactions || isLoadingSummary;

  return (
    <Card className="border border-gray-200 mt-4">
      <CardContent className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex flex-col md:flex-row justify-between items-center mb-6">
            <h3 className="text-xl font-bold mb-2 md:mb-0 text-center md:text-left">KEUANGAN KELAS C BISNIS DIGITAL</h3>
            <div className="flex space-x-2">
              <TabsList className="grid w-full grid-cols-3 gap-1">
                <TabsTrigger value="cashbook">Buku Kas</TabsTrigger>
                <TabsTrigger value="analytics">Analisis</TabsTrigger>
                <TabsTrigger value="integration">Integrasi</TabsTrigger>
              </TabsList>
            </div>
          </div>

          {/* Buku Kas Tab */}
          <TabsContent value="cashbook" className="mt-0">
            <div className="flex justify-end mb-4">
              <button
                onClick={() => setShowAnalytics(!showAnalytics)}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
              >
                {showAnalytics ? 'Lihat Tabel' : 'Lihat Grafik'}
              </button>
            </div>
            
            {isLoading ? (
              <div className="py-8 flex justify-center">
                <Skeleton className="h-64 w-full" />
              </div>
            ) : showAnalytics ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="space-y-8"
              >
                {/* Weekly totals chart */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Total Pembayaran per Minggu</h4>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={barChartData}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip formatter={(value) => formatRupiah(value as number)} />
                          <Legend />
                          <Bar 
                            dataKey="amount" 
                            name="Jumlah" 
                            fill="#82ca9d"
                          >
                            {barChartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Distribution pie chart */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Distribusi Pembayaran per Minggu</h4>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={pieChartData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {pieChartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => formatRupiah(value as number)} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Top 10 students by completion rate */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Top 10 Mahasiswa (Tingkat Pelunasan)</h4>
                    <div className="space-y-3">
                      {topStudents.map((student, index) => (
                        <div key={index} className="flex flex-col">
                          <div className="flex justify-between mb-1">
                            <span className="text-sm font-medium">{student.name}</span>
                            <span className="text-sm font-medium">{student.completed.toFixed(0)}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2.5">
                            <div 
                              className="bg-blue-600 h-2.5 rounded-full" 
                              style={{ width: `${student.completed}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="overflow-x-auto"
              >
                <table className="min-w-full border-collapse border border-gray-300 text-sm">
                  <thead>
                    <tr className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                      <th className="border border-gray-300 py-2 px-3 text-center">NO</th>
                      <th className="border border-gray-300 py-2 px-3 text-center">NIM</th>
                      <th className="border border-gray-300 py-2 px-3 text-center">NAMA</th>
                      {weeks.map((week) => (
                        <th 
                          key={week} 
                          className="border border-gray-300 py-2 px-3 text-center"
                        >
                          {week}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {students.map((student, index) => (
                      <tr key={student.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="border border-gray-300 py-2 px-3 text-center">{index + 1}</td>
                        <td className="border border-gray-300 py-2 px-3">{student.nim}</td>
                        <td className="border border-gray-300 py-2 px-3">{student.name}</td>
                        {weeks.map((week) => (
                          <td 
                            key={`${student.id}-${week}`} 
                            className="border border-gray-300 py-2 px-3 text-right"
                          >
                            {student.payments && Object.prototype.hasOwnProperty.call(student.payments, week) && student.payments[week as keyof typeof student.payments] ? 'Rp 10.000,00' : ""}
                          </td>
                        ))}
                      </tr>
                    ))}
                    <tr className="bg-blue-100 font-semibold text-blue-800">
                      <td colSpan={3} className="border border-gray-300 py-2 px-3 text-right">TOTAL PERMINGGU</td>
                      {weeks.map((week) => (
                        <td key={`total-${week}`} className="border border-gray-300 py-2 px-3 text-right">
                          {weeklyTotals && Object.prototype.hasOwnProperty.call(weeklyTotals, week) && weeklyTotals[week as keyof typeof weeklyTotals] > 0 ? formatRupiah(weeklyTotals[week as keyof typeof weeklyTotals]) : ""}
                        </td>
                      ))}
                    </tr>
                    <tr className="bg-blue-200 font-bold text-blue-900">
                      <td colSpan={3} className="border border-gray-300 py-2 px-3 text-right">TOTAL KESELURUHAN</td>
                      <td colSpan={weeks.length} className="border border-gray-300 py-2 px-3 pl-4">
                        {formatRupiah(totalPayments)} <span className="ml-2 text-sm">(30,86% dari target Rp 2.224.620,00)</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </motion.div>
            )}
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="mt-0 space-y-6">
            {isLoading ? (
              <div className="py-8 flex justify-center">
                <Skeleton className="h-64 w-full" />
              </div>
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="space-y-6"
              >
                {/* Overview cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                    <CardContent className="p-4">
                      <h4 className="text-lg font-medium text-blue-700">Total Pembayaran</h4>
                      <p className="text-2xl font-bold text-blue-800 mt-2">{formatRupiah(totalPayments)}</p>
                      <p className="text-sm text-blue-600 mt-1">
                        {(progressPercentage).toFixed(1)}% dari target
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                    <CardContent className="p-4">
                      <h4 className="text-lg font-medium text-green-700">Rata-rata Per Minggu</h4>
                      <p className="text-2xl font-bold text-green-800 mt-2">
                        {formatRupiah(totalPayments / Object.values(weeklyTotals).filter(v => v > 0).length)}
                      </p>
                      <p className="text-sm text-green-600 mt-1">
                        Untuk {Object.values(weeklyTotals).filter(v => v > 0).length} minggu
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
                    <CardContent className="p-4">
                      <h4 className="text-lg font-medium text-amber-700">Rata-rata Per Mahasiswa</h4>
                      <p className="text-2xl font-bold text-amber-800 mt-2">
                        {formatRupiah(averagePaymentPerStudent)}
                      </p>
                      <p className="text-sm text-amber-600 mt-1">
                        Dari {students.length} mahasiswa
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                    <CardContent className="p-4">
                      <h4 className="text-lg font-medium text-purple-700">Saldo Akhir</h4>
                      <p className="text-2xl font-bold text-purple-800 mt-2">
                        {formatRupiah(summary.totalBalance)}
                      </p>
                      <p className="text-sm text-purple-600 mt-1">
                        Setelah pengeluaran
                      </p>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Cashbook Timeline Chart */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Timeline Pemasukan dan Pengeluaran</h4>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <ComposedChart
                          data={cashbookTimeline}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip formatter={(value) => formatRupiah(value as number)} />
                          <Legend />
                          <Bar dataKey="income" name="Pemasukan" stackId="a" fill="#4ade80" />
                          <Bar dataKey="expense" name="Pengeluaran" stackId="a" fill="#f87171" />
                          <Line type="monotone" dataKey="amount" name="Total" stroke="#8884d8" dot={false} />
                        </ComposedChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Balance Timeline Chart */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Perkembangan Saldo</h4>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={cashbookBalanceTimeline}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="date" />
                          <YAxis />
                          <Tooltip formatter={(value) => formatRupiah(value as number)} />
                          <Legend />
                          <Area 
                            type="monotone" 
                            dataKey="balance" 
                            name="Saldo" 
                            stroke="#8884d8" 
                            fill="#8884d8" 
                            fillOpacity={0.3}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Student Completion Distribution */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Distribusi Tingkat Pelunasan Mahasiswa</h4>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { range: '< 40%', count: studentCompletionRates.filter(s => s.completed < 40).length },
                            { range: '40-60%', count: studentCompletionRates.filter(s => s.completed >= 40 && s.completed < 60).length },
                            { range: '60-80%', count: studentCompletionRates.filter(s => s.completed >= 60 && s.completed < 80).length },
                            { range: '80-100%', count: studentCompletionRates.filter(s => s.completed >= 80).length }
                          ]}
                          margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="range" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar 
                            dataKey="count" 
                            name="Jumlah Mahasiswa" 
                            fill="#8884d8"
                          >
                            <Cell fill="#FF8042" />
                            <Cell fill="#FFBB28" />
                            <Cell fill="#00C49F" />
                            <Cell fill="#0088FE" />
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </TabsContent>

          {/* Integration Tab */}
          <TabsContent value="integration" className="mt-0 space-y-6">
            {isLoading ? (
              <div className="py-8 flex justify-center">
                <Skeleton className="h-64 w-full" />
              </div>
            ) : (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="space-y-6"
              >
                {/* Financial Summary */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Ringkasan Keuangan</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <div className="flex flex-col p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                        <span className="text-sm font-medium text-blue-600">Total Saldo</span>
                        <span className="text-xl font-bold text-blue-800">{formatRupiah(summary.totalBalance)}</span>
                      </div>
                      
                      <div className="flex flex-col p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
                        <span className="text-sm font-medium text-green-600">Kontribusi Bulanan</span>
                        <span className="text-xl font-bold text-green-800">{formatRupiah(summary.monthlyContributions)}</span>
                      </div>
                      
                      <div className="flex flex-col p-4 bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg">
                        <span className="text-sm font-medium text-amber-600">Pengeluaran Tertunda</span>
                        <span className="text-xl font-bold text-amber-800">{formatRupiah(summary.pendingExpenses)}</span>
                      </div>
                      
                      <div className="flex flex-col p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
                        <span className="text-sm font-medium text-purple-600">Total Pembayaran Kas</span>
                        <span className="text-xl font-bold text-purple-800">{formatRupiah(totalPayments)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                {/* All Transactions */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Semua Transaksi</h4>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Tanggal
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Deskripsi
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Jenis
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                            <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Jumlah
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {allTransactions
                            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                            .map((transaction, index) => (
                              <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {new Date(transaction.date).toLocaleDateString('id-ID')}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {transaction.description}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                    transaction.type === 'Income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                                  }`}>
                                    {transaction.type === 'Income' ? 'Pemasukan' : 'Pengeluaran'}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                    transaction.status === 'completed' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'
                                  }`}>
                                    {transaction.status === 'completed' ? 'Selesai' : 'Tertunda'}
                                  </span>
                                </td>
                                <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium text-right ${
                                  transaction.type === 'Income' ? 'text-green-600' : 'text-red-600'
                                }`}>
                                  {transaction.type === 'Income' ? '+' : '-'}{formatRupiah(transaction.amount)}
                                </td>
                              </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Integration Summary */}
                <Card>
                  <CardContent className="p-4">
                    <h4 className="text-lg font-semibold mb-4">Ringkasan Integrasi</h4>
                    <div className="space-y-4">
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <h5 className="font-medium text-blue-800 mb-2">Integrasi Buku Kas dengan Transaksi</h5>
                        <p className="text-blue-700">Semua pembayaran kas mingguan sudah terintegrasi dengan transaksi keuangan umum. Total {cashbookTransactions.length} transaksi kas telah diintegrasikan.</p>
                      </div>
                      
                      <div className="bg-green-50 p-4 rounded-lg">
                        <h5 className="font-medium text-green-800 mb-2">Kontribusi Kas terhadap Total Saldo</h5>
                        <p className="text-green-700">
                          Kontribusi kas kelas mencapai {formatRupiah(totalPayments)} dari total saldo {formatRupiah(summary.totalBalance)}, 
                          atau sekitar {((totalPayments / parseFloat(summary.totalBalance)) * 100).toFixed(1)}% dari total saldo.
                        </p>
                      </div>
                      
                      <div className="bg-amber-50 p-4 rounded-lg">
                        <h5 className="font-medium text-amber-800 mb-2">Status Pembayaran Mahasiswa</h5>
                        <p className="text-amber-700">
                          Dari total {students.length} mahasiswa, {studentCompletionRates.filter(s => s.completed >= 80).length} mahasiswa telah membayar ≥80% 
                          dari total pembayaran. {studentCompletionRates.filter(s => s.completed < 40).length} mahasiswa masih di bawah 40% pembayaran.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}