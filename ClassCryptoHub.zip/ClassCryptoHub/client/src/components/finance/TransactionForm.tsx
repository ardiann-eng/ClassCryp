import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { insertTransactionSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Extend schema with validation
const formSchema = insertTransactionSchema.extend({
  amount: z.string().min(1, "Amount is required"),
  description: z.string().min(3, "Description must be at least 3 characters"),
  date: z.string().min(1, "Date is required"),
});

export default function TransactionForm() {
  const { toast } = useToast();
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: "Income",
      amount: "",
      description: "",
      date: new Date().toISOString().split("T")[0],
      status: "completed",
    },
  });
  
  const mutation = useMutation({
    mutationFn: (values: z.infer<typeof formSchema>) => {
      // Convert the date string to a Date object before sending
      const processedValues = {
        ...values,
        amount: parseFloat(values.amount),
        date: new Date(values.date)
      };
      
      return apiRequest("/api/transactions", {
        method: "POST",
        body: JSON.stringify(processedValues),
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    onSuccess: async () => {
      toast({
        title: "Transaction added",
        description: "The transaction has been successfully added.",
      });
      form.reset({
        type: "Income",
        amount: "",
        description: "",
        date: new Date().toISOString().split("T")[0],
        status: "completed",
      });
      await queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      await queryClient.invalidateQueries({ queryKey: ["/api/financial-summary"] });
    },
    onError: (error) => {
      toast({
        title: "Error adding transaction",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  function onSubmit(values: z.infer<typeof formSchema>) {
    mutation.mutate(values);
  }
  
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-8">
      <h3 className="text-lg font-semibold mb-4">Update Financial Records</h3>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Transaction Type</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a transaction type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Income">Income</SelectItem>
                      <SelectItem value="Expense">Expense</SelectItem>
                      <SelectItem value="Investment">Investment</SelectItem>
                      <SelectItem value="Withdrawal">Withdrawal</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500">$</span>
                    </div>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        placeholder="0.00" 
                        min="0" 
                        step="0.01"
                        className="pl-7" 
                      />
                    </FormControl>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    placeholder="Enter transaction description" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="date"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Date</FormLabel>
                <FormControl>
                  <Input 
                    {...field} 
                    type="date"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="flex justify-end">
            <Button 
              type="submit" 
              className="bg-primary text-white"
              disabled={mutation.isPending}
            >
              {mutation.isPending ? "Adding..." : "Add Transaction"}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
