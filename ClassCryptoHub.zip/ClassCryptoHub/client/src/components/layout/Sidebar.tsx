import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Megaphone, 
  Wallet, 
  Mail, 
  Coins,
  Users
} from "lucide-react";

const navigation = [
  { name: "Home", href: "/", icon: Home },
  { name: "Mahasiswa", href: "/students", icon: Users },
  { name: "Pengumuman & Jadwal", href: "/announcements", icon: Megaphone },
  { name: "Keuangan", href: "/finance", icon: Wallet },
  { name: "Kontak", href: "/contact", icon: Mail },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="lg:w-64 lg:fixed lg:inset-y-0 lg:z-50 bg-white border-r border-gray-200 lg:overflow-y-auto">
      <div className="flex flex-col h-full">
        {/* Logo */}
        <div className="flex items-center justify-center p-4 border-b border-gray-200">
          <div className="text-2xl font-bold text-primary flex items-center">
            <Coins className="mr-2" />
            <span>CryptGen</span>
          </div>
        </div>
        
        {/* Navigation Links */}
        <nav className="flex-1 p-4 space-y-1">
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center p-3 rounded-lg font-medium",
                location === item.href
                  ? "text-primary bg-blue-50"
                  : "text-gray-700 hover:bg-gray-100"
              )}
            >
              <item.icon className="w-5 h-5 mr-3" />
              <span>{item.name}</span>
            </Link>
          ))}
        </nav>
        
        {/* Footer Info */}
        <div className="p-4 border-t border-gray-200 text-sm text-gray-500">
          <p>© {new Date().getFullYear()} CryptGen</p>
          <p>Cryptocurrency Learning Community</p>
        </div>
      </div>
    </aside>
  );
}
