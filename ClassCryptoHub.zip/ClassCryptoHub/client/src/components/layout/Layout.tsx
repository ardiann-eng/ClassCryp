import { ReactNode } from "react";
import Sidebar from "./Sidebar";
import MobileHeader from "./MobileHeader";

interface LayoutProps {
  children: ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      <Sidebar />
      <MobileHeader />
      
      <main className="flex-1 lg:pl-64 pb-10">
        {children}
      </main>
    </div>
  );
}
