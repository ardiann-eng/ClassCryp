import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Coins, Menu, Home, Megaphone, Wallet, Mail, Users } from "lucide-react";

const navigation = [
  { name: "Home", href: "/", icon: Home },
  { name: "Mahasiswa", href: "/students", icon: Users },
  { name: "Pengumuman & Jadwal", href: "/announcements", icon: Megaphone },
  { name: "Keuangan", href: "/finance", icon: Wallet },
  { name: "Kontak", href: "/contact", icon: Mail },
];

export default function MobileHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <>
      <div className="lg:hidden fixed top-0 inset-x-0 z-50 bg-white border-b border-gray-200">
        <div className="flex items-center justify-between p-4">
          <div className="text-xl font-bold text-primary flex items-center">
            <Coins className="mr-2" />
            <span>CryptGen</span>
          </div>
          <button
            onClick={toggleMenu}
            className="text-gray-600 focus:outline-none"
            aria-label="Toggle menu"
          >
            <Menu className="text-xl" />
          </button>
        </div>
        
        {/* Mobile Navigation Menu */}
        <div className={cn("bg-white border-b border-gray-200 p-4 space-y-2", isMenuOpen ? "block" : "hidden")}>
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              onClick={closeMenu}
              className={cn(
                "block p-2 rounded font-medium flex items-center",
                location === item.href ? "text-primary" : "text-gray-700 hover:bg-gray-100"
              )}
            >
              <item.icon className="mr-2 h-5 w-5" /> {item.name}
            </Link>
          ))}
        </div>
      </div>
      
      {/* Spacer for mobile header */}
      <div className="lg:hidden h-16"></div>
    </>
  );
}
