import { Card, CardContent } from "@/components/ui/card";
import { Calendar } from "lucide-react";
import { format } from "date-fns";
import type { Announcement } from "@shared/schema";

interface AnnouncementCardProps {
  announcement: Announcement;
}

export default function AnnouncementCard({ announcement }: AnnouncementCardProps) {
  return (
    <Card className="mb-6 border border-gray-200">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
          <h3 className="font-semibold text-xl text-primary">{announcement.title}</h3>
          <div className="text-sm text-gray-500 flex items-center mt-2 md:mt-0">
            <Calendar className="mr-2 h-4 w-4" />
            <span>Posted: {format(new Date(announcement.date), "MMMM d, yyyy")}</span>
          </div>
        </div>
        <p className="text-gray-700 mb-4">{announcement.content}</p>
        <div className="flex justify-end">
          <button className="text-primary hover:text-blue-700 font-medium flex items-center">
            Read more <span className="ml-2">→</span>
          </button>
        </div>
      </CardContent>
    </Card>
  );
}
