import { useState, useRef } from 'react';
import { Button } from "@/components/ui/button";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Upload, Camera } from "lucide-react";
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';

interface MemberPhotoUploaderProps {
  memberId: number;
  memberName: string;
  currentImageUrl?: string;
}

export default function MemberPhotoUploader({ 
  memberId, 
  memberName,
  currentImageUrl 
}: MemberPhotoUploaderProps) {
  const [open, setOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();

  // Mutation for uploading photo
  const uploadMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      return apiRequest(`/api/members/${memberId}/photo`, {
        method: 'POST',
        body: formData,
      });
    },
    onSuccess: (data) => {
      toast({
        title: "Foto berhasil diupload",
        description: `Foto untuk ${memberName} telah diperbarui.`,
      });
      
      // Invalidate both members and students queries since they share the same photo
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
      queryClient.invalidateQueries({ queryKey: ['/api/students'] });
      queryClient.invalidateQueries({ queryKey: ['/api/class-cashbook'] });
      
      setOpen(false);
      setSelectedFile(null);
      setPreview(null);
    },
    onError: (error) => {
      console.error("Error uploading photo:", error);
      toast({
        title: "Gagal mengupload foto",
        description: "Terjadi kesalahan saat mengupload foto. Silakan coba lagi.",
        variant: "destructive",
      });
    }
  });

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 5 * 1024 * 1024) { // 5MB max
        toast({
          title: "File terlalu besar",
          description: "Ukuran maksimum file adalah 5MB",
          variant: "destructive",
        });
        return;
      }
      
      setSelectedFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Trigger file input click
  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedFile) {
      toast({
        title: "Tidak ada file yang dipilih",
        description: "Silakan pilih foto untuk diupload",
        variant: "destructive",
      });
      return;
    }
    
    const formData = new FormData();
    formData.append('photo', selectedFile);
    
    uploadMutation.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm" 
          className="absolute bottom-2 right-2 rounded-full w-8 h-8 p-0 bg-primary bg-opacity-70 hover:bg-opacity-100 border-0"
          aria-label="Upload Foto"
        >
          <Camera className="h-4 w-4 text-white" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Upload Foto</DialogTitle>
          <DialogDescription>
            Upload foto untuk {memberName}. Ukuran maksimum file 5MB.
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <div 
            className="border-2 border-dashed rounded-lg p-4 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition"
            onClick={triggerFileInput}
          >
            {preview ? (
              <div className="mb-4 relative">
                <img 
                  src={preview} 
                  alt="Preview" 
                  className="w-32 h-32 object-cover rounded-full border" 
                />
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="absolute bottom-0 right-0 rounded-full w-6 h-6 p-0"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedFile(null);
                    setPreview(null);
                  }}
                >
                  ✕
                </Button>
              </div>
            ) : (
              <Upload className="h-10 w-10 text-gray-400 mb-2" />
            )}
            
            <p className="text-sm text-gray-500">
              {preview ? "Klik untuk mengubah foto" : "Klik untuk memilih foto"}
            </p>
            
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
          </div>
          
          {currentImageUrl && !preview && (
            <div className="mt-4">
              <p className="text-sm text-gray-500 mb-2">Foto saat ini:</p>
              <img 
                src={currentImageUrl} 
                alt={`Foto ${memberName}`} 
                className="w-16 h-16 object-cover rounded-full border" 
              />
            </div>
          )}
        </div>
        
        <DialogFooter>
          <Button 
            type="button" 
            variant="outline" 
            onClick={() => {
              setOpen(false);
              setSelectedFile(null);
              setPreview(null);
            }}
          >
            Batal
          </Button>
          <Button 
            type="button" 
            onClick={handleSubmit}
            disabled={uploadMutation.isPending || !selectedFile}
          >
            {uploadMutation.isPending ? "Mengupload..." : "Upload"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}