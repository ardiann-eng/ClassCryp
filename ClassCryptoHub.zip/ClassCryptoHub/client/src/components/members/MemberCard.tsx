import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Twitter, Linkedin, Mail } from "lucide-react";
import type { Member } from "@shared/schema";
import MemberPhotoUploader from "./MemberPhotoUploader";

interface MemberCardProps {
  member: Member;
}

export default function MemberCard({ member }: MemberCardProps) {
  // Get the initials for the Avatar fallback
  const getInitials = (name: string): string => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .substring(0, 2); // Maksimal 2 huruf untuk avatar fallback
  };

  return (
    <Card className="hover:shadow-md transition border border-gray-200">
      <CardContent className="p-4">
        <div className="flex flex-col items-center">
          <div className="relative">
            <Avatar className="w-24 h-24 mb-3">
              <AvatarImage src={member.imageUrl || ''} alt={`${member.name} profile picture`} />
              <AvatarFallback>{getInitials(member.name)}</AvatarFallback>
            </Avatar>
            <MemberPhotoUploader 
              memberId={member.id} 
              memberName={member.name}
              currentImageUrl={member.imageUrl ?? undefined}
            />
          </div>
          <h3 className="font-semibold text-lg">{member.name}</h3>
          <p className="text-gray-600 text-sm mb-2">{member.role}</p>
          <div className="flex space-x-2 text-gray-400">
            {member.twitter && (
              <a 
                href={`https://twitter.com/${member.twitter}`} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="hover:text-primary"
                aria-label={`${member.name}'s Twitter profile`}
              >
                <Twitter size={16} />
              </a>
            )}
            {member.linkedin && (
              <a 
                href={`https://linkedin.com/in/${member.linkedin}`} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="hover:text-primary"
                aria-label={`${member.name}'s LinkedIn profile`}
              >
                <Linkedin size={16} />
              </a>
            )}
            {member.email && (
              <a 
                href={`mailto:${member.email}`} 
                className="hover:text-primary"
                aria-label={`Email ${member.name}`}
              >
                <Mail size={16} />
              </a>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
