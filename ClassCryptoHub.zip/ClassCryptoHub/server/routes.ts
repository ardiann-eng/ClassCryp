import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import {
  insertMemberSchema,
  insertAnnouncementSchema,
  insertEventSchema,
  insertTransactionSchema,
  insertContactSchema,
  insertFinancialSummarySchema,
  insertStudentSchema,
  insertStudentPaymentSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = express.Router();
  
  // Members routes
  apiRouter.get("/members", async (_req: Request, res: Response) => {
    const members = await storage.getMembers();
    res.json(members);
  });
  
  apiRouter.get("/members/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid member ID" });
    }
    
    const member = await storage.getMemberById(id);
    if (!member) {
      return res.status(404).json({ message: "Member not found" });
    }
    
    res.json(member);
  });
  
  apiRouter.post("/members", async (req: Request, res: Response) => {
    try {
      const newMember = insertMemberSchema.parse(req.body);
      const member = await storage.createMember(newMember);
      res.status(201).json(member);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid member data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create member" });
    }
  });
  
  // Upload member photo
  apiRouter.post("/members/:id/photo", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid member ID" });
      }
      
      const member = await storage.getMemberById(id);
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }

      // In a production environment, we would handle file uploads to cloud storage
      // For the demo, we'll generate a random avatar URL based on the member ID
      // This simulates what would happen if we stored the image and received a URL back
      const randomSeed = Math.floor(Math.random() * 100); // Give some variety in avatars
      const photoUrl = `https://i.pravatar.cc/300?img=${id % 70 + randomSeed}`;
      
      // Update member with new image URL
      const updatedMember = await storage.updateMemberPhoto(id, photoUrl);
      
      res.status(200).json({ message: "Photo uploaded successfully", member: updatedMember });
    } catch (error) {
      console.error("Error uploading photo:", error);
      res.status(500).json({ message: "Failed to upload photo" });
    }
  });
  
  // Announcements routes
  apiRouter.get("/announcements", async (_req: Request, res: Response) => {
    const announcements = await storage.getAnnouncements();
    res.json(announcements);
  });
  
  apiRouter.get("/announcements/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid announcement ID" });
    }
    
    const announcement = await storage.getAnnouncementById(id);
    if (!announcement) {
      return res.status(404).json({ message: "Announcement not found" });
    }
    
    res.json(announcement);
  });
  
  apiRouter.post("/announcements", async (req: Request, res: Response) => {
    try {
      const newAnnouncement = insertAnnouncementSchema.parse(req.body);
      const announcement = await storage.createAnnouncement(newAnnouncement);
      res.status(201).json(announcement);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid announcement data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create announcement" });
    }
  });
  
  // Events routes
  apiRouter.get("/events", async (_req: Request, res: Response) => {
    const events = await storage.getEvents();
    res.json(events);
  });
  
  apiRouter.get("/events/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid event ID" });
    }
    
    const event = await storage.getEventById(id);
    if (!event) {
      return res.status(404).json({ message: "Event not found" });
    }
    
    res.json(event);
  });
  
  apiRouter.post("/events", async (req: Request, res: Response) => {
    try {
      const newEvent = insertEventSchema.parse(req.body);
      const event = await storage.createEvent(newEvent);
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid event data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create event" });
    }
  });
  
  // Transactions routes
  apiRouter.get("/transactions", async (_req: Request, res: Response) => {
    const transactions = await storage.getTransactions();
    res.json(transactions);
  });
  
  apiRouter.get("/transactions/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid transaction ID" });
    }
    
    const transaction = await storage.getTransactionById(id);
    if (!transaction) {
      return res.status(404).json({ message: "Transaction not found" });
    }
    
    res.json(transaction);
  });
  
  apiRouter.post("/transactions", async (req: Request, res: Response) => {
    try {
      const newTransaction = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(newTransaction);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid transaction data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });
  
  // Contact route
  apiRouter.post("/contact", async (req: Request, res: Response) => {
    try {
      const newContact = insertContactSchema.parse(req.body);
      const contact = await storage.createContact(newContact);
      res.status(201).json(contact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid contact data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit contact form" });
    }
  });
  
  // Financial summary routes
  apiRouter.get("/financial-summary", async (_req: Request, res: Response) => {
    const summary = await storage.getFinancialSummary();
    if (!summary) {
      return res.status(404).json({ message: "Financial summary not found" });
    }
    
    res.json(summary);
  });
  
  apiRouter.post("/financial-summary", async (req: Request, res: Response) => {
    try {
      const newSummary = insertFinancialSummarySchema.parse(req.body);
      const summary = await storage.updateFinancialSummary(newSummary);
      res.json(summary);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid financial summary data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update financial summary" });
    }
  });

  // Students routes
  apiRouter.get("/students", async (_req: Request, res: Response) => {
    const students = await storage.getStudents();
    res.json(students);
  });
  
  apiRouter.get("/students/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid student ID" });
    }
    
    const student = await storage.getStudentById(id);
    if (!student) {
      return res.status(404).json({ message: "Student not found" });
    }
    
    res.json(student);
  });
  
  apiRouter.post("/students", async (req: Request, res: Response) => {
    try {
      const newStudent = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(newStudent);
      res.status(201).json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid student data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create student" });
    }
  });

  // Student Payments routes
  apiRouter.get("/student-payments", async (_req: Request, res: Response) => {
    const payments = await storage.getStudentPayments();
    res.json(payments);
  });
  
  apiRouter.get("/student-payments/student/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      return res.status(400).json({ message: "Invalid student ID" });
    }
    
    const payments = await storage.getStudentPaymentsByStudentId(id);
    res.json(payments);
  });

  apiRouter.get("/student-payments/week/:weekLabel", async (req: Request, res: Response) => {
    const weekLabel = req.params.weekLabel;
    if (!weekLabel) {
      return res.status(400).json({ message: "Invalid week label" });
    }
    
    const payments = await storage.getStudentPaymentByWeek(weekLabel);
    res.json(payments);
  });
  
  apiRouter.post("/student-payments", async (req: Request, res: Response) => {
    try {
      const newPayment = insertStudentPaymentSchema.parse(req.body);
      const payment = await storage.createStudentPayment(newPayment);
      res.status(201).json(payment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid payment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  // Class Cashbook route
  apiRouter.get("/class-cashbook", async (_req: Request, res: Response) => {
    const cashbook = await storage.getClassCashbook();
    res.json(cashbook);
  });
  
  // Register all API routes with /api prefix
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
