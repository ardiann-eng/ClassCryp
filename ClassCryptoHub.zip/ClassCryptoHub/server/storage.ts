import {
  members, type Member, type InsertMember,
  announcements, type Announcement, type InsertAnnouncement,
  events, type Event, type InsertEvent,
  transactions, type Transaction, type InsertTransaction,
  contacts, type Contact, type InsertContact,
  financialSummary, type FinancialSummary, type InsertFinancialSummary,
  students, type Student, type InsertStudent,
  studentPayments, type StudentPayment, type InsertStudentPayment
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, and, sql } from "drizzle-orm";

// Define the storage interface with CRUD methods
export interface IStorage {
  // Members
  getMembers(): Promise<Member[]>;
  getMemberById(id: number): Promise<Member | undefined>;
  createMember(member: InsertMember): Promise<Member>;
  updateMemberPhoto(id: number, imageUrl: string): Promise<Member>;
  
  // Announcements
  getAnnouncements(): Promise<Announcement[]>;
  getAnnouncementById(id: number): Promise<Announcement | undefined>;
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  
  // Events
  getEvents(): Promise<Event[]>;
  getEventById(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  // Transactions
  getTransactions(): Promise<Transaction[]>;
  getTransactionById(id: number): Promise<Transaction | undefined>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  
  // Contacts
  createContact(contact: InsertContact): Promise<Contact>;
  
  // Financial Summary
  getFinancialSummary(): Promise<FinancialSummary | undefined>;
  updateFinancialSummary(summary: InsertFinancialSummary): Promise<FinancialSummary>;
  
  // Students
  getStudents(): Promise<Student[]>;
  getStudentById(id: number): Promise<Student | undefined>;
  getStudentByNim(nim: string): Promise<Student | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  
  // Student Payments
  getStudentPayments(): Promise<StudentPayment[]>;
  getStudentPaymentsByStudentId(studentId: number): Promise<StudentPayment[]>;
  getStudentPaymentByWeek(weekLabel: string): Promise<StudentPayment[]>;
  createStudentPayment(payment: InsertStudentPayment): Promise<StudentPayment>;
  
  // For Class Cashbook
  getClassCashbook(): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  // Members
  async getMembers(): Promise<Member[]> {
    // Get student data first and use it to create member data
    const studentsData = await this.getStudents();
    
    // First try to get members from database
    const existingMembers = await db.select().from(members);
    
    // If there are no members in the database, populate using student data
    if (existingMembers.length === 0 && studentsData.length > 0) {
      // Generate member data from students
      const memberDataToInsert = studentsData.map(student => ({
        name: student.name,
        role: `Mahasiswa - ${student.nim}`,
        imageUrl: student.imageUrl,
        twitter: student.nim.substring(6, 10),
        linkedin: `${student.name.split(' ')[0].toLowerCase()}-${student.nim.substring(6, 10)}`,
        email: `${student.name.split(' ')[0].toLowerCase()}.${student.nim}@student.example.com`
      }));
      
      // Insert all members
      await db.insert(members).values(memberDataToInsert);
      
      // Return the newly inserted members
      return await db.select().from(members);
    }
    
    return existingMembers;
  }

  async getMemberById(id: number): Promise<Member | undefined> {
    const [member] = await db.select().from(members).where(eq(members.id, id));
    return member || undefined;
  }

  async createMember(member: InsertMember): Promise<Member> {
    const [newMember] = await db.insert(members).values(member).returning();
    return newMember;
  }
  
  async updateMemberPhoto(id: number, imageUrl: string): Promise<Member> {
    const [updatedMember] = await db
      .update(members)
      .set({ imageUrl })
      .where(eq(members.id, id))
      .returning();
    
    return updatedMember;
  }

  // Announcements
  async getAnnouncements(): Promise<Announcement[]> {
    return await db.select().from(announcements).orderBy(desc(announcements.date));
  }

  async getAnnouncementById(id: number): Promise<Announcement | undefined> {
    const [announcement] = await db.select().from(announcements).where(eq(announcements.id, id));
    return announcement || undefined;
  }

  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const [newAnnouncement] = await db.insert(announcements).values(announcement).returning();
    return newAnnouncement;
  }

  // Events
  async getEvents(): Promise<Event[]> {
    return await db.select().from(events).orderBy(asc(events.date));
  }

  async getEventById(id: number): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event || undefined;
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const [newEvent] = await db.insert(events).values(event).returning();
    return newEvent;
  }

  // Transactions
  async getTransactions(): Promise<Transaction[]> {
    return await db.select().from(transactions).orderBy(desc(transactions.date));
  }

  async getTransactionById(id: number): Promise<Transaction | undefined> {
    const [transaction] = await db.select().from(transactions).where(eq(transactions.id, id));
    return transaction || undefined;
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [newTransaction] = await db.insert(transactions).values(transaction).returning();
    
    // Update financial summary
    await this.updateFinancialSummaryAfterTransaction(newTransaction);
    
    return newTransaction;
  }

  // Contact
  async createContact(contact: InsertContact): Promise<Contact> {
    const [newContact] = await db.insert(contacts).values(contact).returning();
    return newContact;
  }

  // Financial Summary
  async getFinancialSummary(): Promise<FinancialSummary | undefined> {
    const summaries = await db.select().from(financialSummary);
    if (summaries.length === 0) return undefined;
    return summaries[0];
  }

  async updateFinancialSummary(summary: InsertFinancialSummary): Promise<FinancialSummary> {
    // Check if there's an existing record
    const existingSummary = await this.getFinancialSummary();
    
    if (existingSummary) {
      // Update the existing record
      const [updatedSummary] = await db
        .update(financialSummary)
        .set({ ...summary, lastUpdated: new Date() })
        .where(eq(financialSummary.id, existingSummary.id))
        .returning();
      return updatedSummary;
    } else {
      // Insert a new record
      const [newSummary] = await db
        .insert(financialSummary)
        .values({ ...summary, lastUpdated: new Date() })
        .returning();
      return newSummary;
    }
  }

  // Helper method to update financial summary after a transaction is added
  private async updateFinancialSummaryAfterTransaction(transaction: Transaction): Promise<void> {
    const summary = await this.getFinancialSummary();
    if (!summary) return;
    
    let totalBalance = Number(summary.totalBalance);
    let pendingExpenses = Number(summary.pendingExpenses);
    let pendingExpensesCount = summary.pendingExpensesCount;
    
    const amount = Number(transaction.amount);
    
    // Update total balance based on transaction type
    if (transaction.status === 'completed') {
      if (transaction.type === 'Income') {
        totalBalance += amount;
      } else if (transaction.type === 'Expense' || transaction.type === 'Investment') {
        totalBalance -= amount;
      } else if (transaction.type === 'Withdrawal') {
        totalBalance -= amount;
      }
    } else if (transaction.status === 'pending') {
      if (transaction.type === 'Expense') {
        pendingExpenses += amount;
        pendingExpensesCount += 1;
      }
    }
    
    await this.updateFinancialSummary({
      ...summary,
      totalBalance: totalBalance.toString(),
      pendingExpenses: pendingExpenses.toString(),
      pendingExpensesCount,
      lastUpdated: new Date()
    });
  }

  // Students
  async getStudents(): Promise<Student[]> {
    return await db.select().from(students).orderBy(asc(students.name));
  }

  async getStudentById(id: number): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student || undefined;
  }

  async getStudentByNim(nim: string): Promise<Student | undefined> {
    const [student] = await db.select().from(students).where(eq(students.nim, nim));
    return student || undefined;
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const [newStudent] = await db.insert(students).values(student).returning();
    return newStudent;
  }

  // Student Payments
  async getStudentPayments(): Promise<StudentPayment[]> {
    return await db.select().from(studentPayments);
  }

  async getStudentPaymentsByStudentId(studentId: number): Promise<StudentPayment[]> {
    return await db.select()
      .from(studentPayments)
      .where(eq(studentPayments.studentId, studentId));
  }

  async getStudentPaymentByWeek(weekLabel: string): Promise<StudentPayment[]> {
    return await db.select()
      .from(studentPayments)
      .where(eq(studentPayments.weekLabel, weekLabel));
  }

  async createStudentPayment(payment: InsertStudentPayment): Promise<StudentPayment> {
    const [newPayment] = await db.insert(studentPayments).values(payment).returning();
    return newPayment;
  }

  // Get Class Cashbook - returns data formatted for class cashbook display
  async getClassCashbook(): Promise<any[]> {
    // First get all students
    const allStudents = await this.getStudents();
    
    // Minggu labels
    const weekLabels = [
      "Minggu 1", "Minggu 2", "Minggu 3", "Minggu 4", 
      "Minggu 5", "Minggu 6", "Minggu 7", "Minggu 8", "Minggu 9"
    ];
    
    // For each student, get their payments
    const result = await Promise.all(
      allStudents.map(async (student) => {
        const payments = await this.getStudentPaymentsByStudentId(student.id);
        
        // Create an object with payments by week
        const weeklyPayments: { [key: string]: string | null } = {};
        
        // Initialize with null for all weeks
        weekLabels.forEach(week => {
          weeklyPayments[week] = null;
        });
        
        // Fill in actual payments
        payments.forEach(payment => {
          weeklyPayments[payment.weekLabel] = payment.amount.toString();
        });
        
        // Return combined object
        return {
          id: student.id,
          nim: student.nim,
          name: student.name,
          imageUrl: student.imageUrl,
          payments: weeklyPayments
        };
      })
    );
    
    return result;
  }

  // Seed student data and related payments 
  async seedStudentData(): Promise<void> {
    // Seed students from the class file
    const seedStudents: InsertStudent[] = [
      { nim: "23097500021", name: "NUR AISYAH", imageUrl: "https://i.pravatar.cc/150?img=1" },
      { nim: "23097500023", name: "JESIKA PALEPONG", imageUrl: "https://i.pravatar.cc/150?img=2" },
      { nim: "23097500024", name: "KAYLA NETHANIA SAID", imageUrl: "https://i.pravatar.cc/150?img=3" },
      { nim: "23097500025", name: "UMNATUL ULA'", imageUrl: "https://i.pravatar.cc/150?img=4" },
      { nim: "23097500026", name: "IIT FEBRIANTI IRWAN PUTRI", imageUrl: "https://i.pravatar.cc/150?img=5" },
      { nim: "23097500027", name: "NUR AKMA", imageUrl: "https://i.pravatar.cc/150?img=6" },
      { nim: "23097500028", name: "AMALIA NURUL JANNAH", imageUrl: "https://i.pravatar.cc/150?img=7" },
      { nim: "23097500029", name: "JELSI NASA", imageUrl: "https://i.pravatar.cc/150?img=8" },
      { nim: "23097500030", name: "VENILIANI SANGGIN", imageUrl: "https://i.pravatar.cc/150?img=9" },
      { nim: "23097501026", name: "ANDI ASHRAF HAK BISYSU", imageUrl: "https://i.pravatar.cc/150?img=10" },
      { nim: "23097501028", name: "MUH LUTHFI MAULUDI LUKMAN", imageUrl: "https://i.pravatar.cc/150?img=11" },
      { nim: "23097501033", name: "AHMAD AQIEL FARRAS", imageUrl: "https://i.pravatar.cc/150?img=12" },
      { nim: "23097501034", name: "MUTHIAH ADIBAH", imageUrl: "https://i.pravatar.cc/150?img=13" },
      { nim: "23097501035", name: "MADE RIZAL APRILLIAN", imageUrl: "https://i.pravatar.cc/150?img=14" },
      { nim: "23097501036", name: "AFIFAH QONITA MUHARANI", imageUrl: "https://i.pravatar.cc/150?img=15" },
      { nim: "23097501037", name: "MUHAMMAD WILDAN RUSLY", imageUrl: "https://i.pravatar.cc/150?img=16" },
      { nim: "23097501038", name: "NISFALAH ZAHRAH RAHMADANI", imageUrl: "https://i.pravatar.cc/150?img=17" },
      { nim: "23097501039", name: "SITI NURHALIZA ADHANI ASRULLAH", imageUrl: "https://i.pravatar.cc/150?img=18" },
      { nim: "23097501040", name: "HUSAYN KHALIL URRAHIM IRFAN", imageUrl: "https://i.pravatar.cc/150?img=19" },
      { nim: "23097501041", name: "MOHAMMAD AFIAT WARGABOJO", imageUrl: "https://i.pravatar.cc/150?img=20" },
      { nim: "23097501042", name: "ARDIYANSA", imageUrl: "https://i.pravatar.cc/150?img=21" },
      { nim: "23097501043", name: "HENGKI SETIAWAN", imageUrl: "https://i.pravatar.cc/150?img=22" },
      { nim: "23097501044", name: "SHASY DUE MAHARANIKA", imageUrl: "https://i.pravatar.cc/150?img=23" },
      { nim: "23097501045", name: "MUHAMMAD AFIQ SYUKRI", imageUrl: "https://i.pravatar.cc/150?img=24" },
      { nim: "23097501047", name: "NICHOLAS JECSON", imageUrl: "https://i.pravatar.cc/150?img=25" },
      { nim: "23097501048", name: "NIGEL TRIFOSA SARAPANG ALLORANTE", imageUrl: "https://i.pravatar.cc/150?img=26" },
      { nim: "23097501207", name: "MUHAMMAD NAUFAL FAQI", imageUrl: "https://i.pravatar.cc/150?img=27" },
      { nim: "23097501209", name: "ZAHRA MEIFTA AMALIA", imageUrl: "https://i.pravatar.cc/150?img=28" },
      { nim: "23097501230", name: "NIA RATDANI", imageUrl: "https://i.pravatar.cc/150?img=29" },
      { nim: "23097501231", name: "MUH TAUFIK H", imageUrl: "https://i.pravatar.cc/150?img=30" },
      { nim: "23097501232", name: "ARRISYAH", imageUrl: "https://i.pravatar.cc/150?img=31" },
      { nim: "23097501233", name: "AHMAD ZAKI AL AFIF", imageUrl: "https://i.pravatar.cc/150?img=32" },
      { nim: "23097501234", name: "RAYHAN KUTLANA", imageUrl: "https://i.pravatar.cc/150?img=33" },
      { nim: "23097501235", name: "ZULFADLY SYAHPHALLEVI MANGUNTEREN", imageUrl: "https://i.pravatar.cc/150?img=34" },
      { nim: "23097501236", name: "AHMAD ARIF HIDAYAT", imageUrl: "https://i.pravatar.cc/150?img=35" },
      { nim: "23097501237", name: "FADYAH PUTRI AMELIAH", imageUrl: "https://i.pravatar.cc/150?img=36" },
      { nim: "23097501238", name: "KAULZAKI", imageUrl: "https://i.pravatar.cc/150?img=37" },
      { nim: "23097501239", name: "ARHAM FATURRAHMAN", imageUrl: "https://i.pravatar.cc/150?img=38" },
      { nim: "23097501240", name: "AL FIRA DAMAYANTI", imageUrl: "https://i.pravatar.cc/150?img=39" },
      { nim: "23097501241", name: "RAISYAH ALIEF KAZRAJ", imageUrl: "https://i.pravatar.cc/150?img=40" }
    ];

    // Insert students and get their IDs
    const insertedStudents = await db.insert(students).values(seedStudents).returning({ id: students.id, nim: students.nim });
    
    // Payment data by week
    const payments = [
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // NUR AISYAH
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // JESIKA PALEPONG
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }, // KAYLA NETHANIA SAID
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }, // UMNATUL ULA'
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }, // IIT FEBRIANTI IRWAN PUTRI
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // NUR AKMA
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 5, 8: 0, 9: 0 }, // AMALIA NURUL JANNAH
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 5, 8: 5, 9: 0 }, // JELSI NASA
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // VENILIANI SANGGIN
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 5, 8: 0, 9: 0 }, // ANDI ASHRAF HAK BISYSU
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // MUH LUTHFI MAULUDI LUKMAN
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // AHMAD AQIEL FARRAS
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 5, 8: 0, 9: 0 }, // MUTHIAH ADIBAH
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }, // MADE RIZAL APRILLIAN
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }, // AFIFAH QONITA MUHARANI
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // MUHAMMAD WILDAN RUSLY
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // NISFALAH ZAHRAH RAHMADANI
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 0, 8: 0, 9: 0 }, // SITI NURHALIZA ADHANI ASRULLAH
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // HUSAYN KHALIL URRAHIM IRFAN
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 5, 8: 5, 9: 0 }, // MOHAMMAD AFIAT WARGABOJO
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // ARDIYANSA
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 5, 8: 5, 9: 0 }, // HENGKI SETIAWAN
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // SHASY DUE MAHARANIKA
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // MUHAMMAD AFIQ SYUKRI
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // NICHOLAS JECSON
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // NIGEL TRIFOSA SARAPANG ALLORANTE
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // MUHAMMAD NAUFAL FAQI
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // ZAHRA MEIFTA AMALIA
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 5, 7: 5, 8: 5, 9: 0 }, // NIA RATDANI
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // MUH TAUFIK H
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // ARRISYAH
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // AHMAD ZAKI AL AFIF
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }, // RAYHAN KUTLANA
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // ZULFADLY SYAHPHALLEVI MANGUNTEREN
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // AHMAD ARIF HIDAYAT
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // FADYAH PUTRI AMELIAH
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // KAULZAKI
      { 1: 5, 2: 5, 3: 5, 4: 5, 5: 5, 6: 0, 7: 0, 8: 0, 9: 0 }, // ARHAM FATURRAHMAN
      { 1: 5, 2: 5, 3: 5, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }, // AL FIRA DAMAYANTI
      { 1: 5, 2: 5, 3: 5, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0 }  // RAISYAH ALIEF KAZRAJ
    ];
    
    // Create payment records
    const paymentRecords: InsertStudentPayment[] = [];
    
    // Define week labels
    const weekLabels = [
      "Minggu 1", "Minggu 2", "Minggu 3", "Minggu 4", 
      "Minggu 5", "Minggu 6", "Minggu 7", "Minggu 8", "Minggu 9"
    ];
    
    for (let i = 0; i < insertedStudents.length; i++) {
      const student = insertedStudents[i];
      const studentPayments = payments[i];
      
      // Add payments for each week if the amount is greater than 0
      for (const [weekStr, amount] of Object.entries(studentPayments)) {
        const weekIndex = parseInt(weekStr) - 1; // 1-based to 0-based index
        if (amount > 0 && weekIndex >= 0 && weekIndex < weekLabels.length) {
          paymentRecords.push({
            studentId: student.id,
            weekLabel: weekLabels[weekIndex],
            amount: "10000.00", // Rp 10.000,00
            paid: true
          });
        }
      }
    }
    
    if (paymentRecords.length > 0) {
      await db.insert(studentPayments).values(paymentRecords);
    }
  }

  async seedInitialData(): Promise<void> {
    // Check if tables already have data
    const studentCount = await db.select().from(students);
    // Always seed student data if it doesn't exist, regardless of members
    if (studentCount.length === 0) {
      // Seed students first
      await this.seedStudentData();
    }
    
    // Check if members need to be seeded
    const memberCount = await db.select().from(members);
    if (memberCount.length > 0) return; // Skip seeding sample members if they exist
    
    // Seed members
    const seedMembers: InsertMember[] = [
      {
        name: "John Doe",
        role: "Co-founder & Blockchain Expert",
        imageUrl: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80",
        twitter: "johndoe",
        linkedin: "johndoe",
        email: "john@cryptgen.example"
      },
      {
        name: "Sarah Kim",
        role: "Investment Strategist",
        imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80",
        twitter: "sarahkim",
        linkedin: "sarahkim",
        email: "sarah@cryptgen.example"
      },
      {
        name: "David Chen",
        role: "Technical Analyst",
        imageUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80",
        twitter: "davidchen",
        linkedin: "davidchen",
        email: "david@cryptgen.example"
      },
      {
        name: "Emma Wilson",
        role: "Community Manager",
        imageUrl: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&h=256&q=80",
        twitter: "emmawilson",
        linkedin: "emmawilson",
        email: "emma@cryptgen.example"
      }
    ];
    
    await db.insert(members).values(seedMembers);
    
    // Seed announcements
    const seedAnnouncements: InsertAnnouncement[] = [
      {
        title: "New Bitcoin Trading Masterclass",
        content: "We're excited to announce our new Bitcoin Trading Masterclass series, starting next month. These sessions will be led by our expert David Chen and will cover advanced trading strategies, risk management, and technical analysis specifically for Bitcoin markets.",
        date: new Date("2023-10-12T12:00:00")
      },
      {
        title: "Community Investment Update",
        content: "Our community investment pool has achieved a 15% return this quarter. We'll be discussing the current portfolio allocation and potential new investments during our next monthly meeting. Come prepared with your suggestions and analysis.",
        date: new Date("2023-10-05T12:00:00")
      },
      {
        title: "New Member Orientation",
        content: "We're welcoming 5 new members to our community this month! A special orientation session will be held on October 15th to introduce them to our platforms, resources, and community guidelines. All current members are encouraged to attend and help welcome our new participants.",
        date: new Date("2023-09-28T12:00:00")
      }
    ];
    
    await db.insert(announcements).values(seedAnnouncements);
    
    // Seed events
    const seedEvents: InsertEvent[] = [
      {
        title: "New Member Orientation",
        host: "Emma Wilson",
        date: new Date("2023-10-15T14:00:00"),
        endTime: new Date("2023-10-15T16:00:00"),
        location: "Online (Zoom)",
        details: "Introduction to community platforms and resources"
      },
      {
        title: "Monthly Investment Meeting",
        host: "Sarah Kim",
        date: new Date("2023-10-20T18:30:00"),
        endTime: new Date("2023-10-20T20:30:00"),
        location: "Community Center, Room 203",
        details: "Discussion of current portfolio and new investments"
      },
      {
        title: "Bitcoin Trading Masterclass #1",
        host: "David Chen",
        date: new Date("2023-11-05T13:00:00"),
        endTime: new Date("2023-11-05T17:00:00"),
        location: "Online (Zoom)",
        details: "Introduction to advanced Bitcoin trading strategies"
      },
      {
        title: "DeFi Workshop",
        host: "John Doe",
        date: new Date("2023-11-15T19:00:00"),
        endTime: new Date("2023-11-15T21:00:00"),
        location: "Tech Hub, Conference Room A",
        details: "Exploring DeFi protocols and strategies"
      }
    ];
    
    await db.insert(events).values(seedEvents);
    
    // Seed financial summary
    const seedFinancialSummary: InsertFinancialSummary = {
      totalBalance: "8450.00",
      monthlyContributions: "1250.00",
      contributionGrowth: "15% from last month",
      pendingExpenses: "350.00",
      pendingExpensesCount: 3,
      lastUpdated: new Date("2023-10-10T12:00:00")
    };
    
    await db.insert(financialSummary).values(seedFinancialSummary);
    
    // Seed transactions
    const seedTransactions: InsertTransaction[] = [
      {
        type: "Income",
        amount: "1250.00",
        description: "Monthly member contributions",
        date: new Date("2023-10-10T12:00:00"),
        status: "completed"
      },
      {
        type: "Expense",
        amount: "250.00",
        description: "Workshop venue rental",
        date: new Date("2023-10-08T12:00:00"),
        status: "completed"
      },
      {
        type: "Investment",
        amount: "2000.00",
        description: "Ethereum staking investment",
        date: new Date("2023-10-05T12:00:00"),
        status: "completed"
      },
      {
        type: "Expense",
        amount: "150.00",
        description: "Educational materials purchase",
        date: new Date("2023-10-01T12:00:00"),
        status: "pending"
      }
    ];
    
    await db.insert(transactions).values(seedTransactions);
  }
}

export const storage = new DatabaseStorage();
