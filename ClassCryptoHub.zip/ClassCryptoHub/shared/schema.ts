import { pgTable, text, serial, integer, boolean, timestamp, numeric, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Members schema
export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  imageUrl: text("image_url"),
  twitter: text("twitter"),
  linkedin: text("linkedin"),
  email: text("email"),
});

export const insertMemberSchema = createInsertSchema(members).omit({
  id: true,
});

// Announcements schema
export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  date: timestamp("date").notNull().defaultNow(),
});

export const insertAnnouncementSchema = createInsertSchema(announcements).omit({
  id: true,
});

// Events schema
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  host: text("host").notNull(),
  date: timestamp("date").notNull(),
  endTime: timestamp("end_time"),
  location: text("location").notNull(),
  details: text("details"),
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
});

// Transactions schema
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  amount: numeric("amount").notNull(),
  description: text("description").notNull(),
  date: timestamp("date").notNull(),
  status: text("status").notNull().default("pending"),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
});

// Contact messages schema
export const contacts = pgTable("contacts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  subscribed: boolean("subscribed").default(false),
  date: timestamp("date").notNull().defaultNow(),
});

export const insertContactSchema = createInsertSchema(contacts).omit({
  id: true,
});

// Financial summary schema
export const financialSummary = pgTable("financial_summary", {
  id: serial("id").primaryKey(),
  totalBalance: numeric("total_balance").notNull(),
  monthlyContributions: numeric("monthly_contributions").notNull(),
  contributionGrowth: text("contribution_growth"),
  pendingExpenses: numeric("pending_expenses").notNull(),
  pendingExpensesCount: integer("pending_expenses_count").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertFinancialSummarySchema = createInsertSchema(financialSummary).omit({
  id: true,
});

// Types
export type Member = typeof members.$inferSelect;
export type InsertMember = z.infer<typeof insertMemberSchema>;

export type Announcement = typeof announcements.$inferSelect;
export type InsertAnnouncement = z.infer<typeof insertAnnouncementSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = z.infer<typeof insertContactSchema>;

export type FinancialSummary = typeof financialSummary.$inferSelect;
export type InsertFinancialSummary = z.infer<typeof insertFinancialSummarySchema>;

// Students schema
export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  nim: text("nim").notNull().unique(),
  name: text("name").notNull(),
  imageUrl: text("image_url"),
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
});

// Student payments schema
export const studentPayments = pgTable("student_payments", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull().references(() => students.id),
  weekLabel: text("week_label").notNull(), // Menyimpan label seperti "Minggu 1", "Minggu 2", dll
  amount: numeric("amount").notNull(),
  paid: boolean("paid").notNull().default(true),
  date: timestamp("date").notNull().defaultNow(),
});

export const insertStudentPaymentSchema = createInsertSchema(studentPayments).omit({
  id: true,
  date: true,
});

export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;

export type StudentPayment = typeof studentPayments.$inferSelect;
export type InsertStudentPayment = z.infer<typeof insertStudentPaymentSchema>;
